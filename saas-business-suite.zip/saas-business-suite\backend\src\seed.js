const bcrypt = require('bcryptjs');
const prisma = require('./config/prisma');

async function main() {
  console.log('Seeding initial SaaS database with Developer, Admins, Employees, Inventory, and Attendance...');

  // Clear existing data for fresh clean seed
  await prisma.systemAuditLog.deleteMany();
  await prisma.auditTrail.deleteMany();
  await prisma.leaveRequest.deleteMany();
  await prisma.attendance.deleteMany();
  await prisma.inventory.deleteMany();
  await prisma.user.deleteMany();

  const devPassword = await bcrypt.hash('Developer123!', 10);
  const adminPassword = await bcrypt.hash('Admin123!', 10);
  const empPassword = await bcrypt.hash('Employee123!', 10);

  // 1. Create SaaS Developer (1 of 2 max allowed)
  const developer = await prisma.user.create({
    data: {
      name: 'Kamran (SaaS Platform Owner)',
      email: 'developer@saas.com',
      password: devPassword,
      role: 'DEVELOPER',
      isBlocked: false
    }
  });
  console.log('✔ Seeded Developer:', developer.email);

  // 2. Create Active Business Client Admin (Apex Logistics)
  const subEndDate = new Date();
  subEndDate.setDate(subEndDate.getDate() + 30); // 30 days active

  const activeAdmin = await prisma.user.create({
    data: {
      name: 'Robert Vance',
      email: 'admin@corporate.com',
      password: adminPassword,
      role: 'ADMIN',
      businessName: 'Apex Global Logistics & Distribution',
      phone: '+1 (555) 234-8900',
      subscriptionPlan: 'ENTERPRISE_PRO',
      subscriptionEndDate: subEndDate,
      isBlocked: false
    }
  });
  console.log('✔ Seeded Active Admin:', activeAdmin.email);

  // 3. Create a Blocked / Overdue Business Client Admin (to demonstrate SaaS Kill-Switch!)
  const expiredDate = new Date();
  expiredDate.setDate(expiredDate.getDate() - 5); // 5 days overdue

  const blockedAdmin = await prisma.user.create({
    data: {
      name: 'Marcus Sterling',
      email: 'blocked@retail.com',
      password: adminPassword,
      role: 'ADMIN',
      businessName: 'Sterling Retail Chain',
      phone: '+1 (555) 888-9999',
      subscriptionPlan: 'BASIC_TIER',
      subscriptionEndDate: expiredDate,
      isBlocked: true
    }
  });
  console.log('✔ Seeded Blocked Admin (Kill-Switch Active):', blockedAdmin.email);

  // 4. Create System Audit Logs by Developer
  await prisma.systemAuditLog.createMany({
    data: [
      {
        developerId: developer.id,
        targetAdminId: activeAdmin.id,
        action: 'PROVISION_CLIENT',
        details: `Platform Developer provisioned new enterprise tenant "${activeAdmin.businessName}" with 30-day active license.`,
        createdAt: new Date(Date.now() - 7 * 86400000)
      },
      {
        developerId: developer.id,
        targetAdminId: blockedAdmin.id,
        action: 'BLOCK_ADMIN',
        details: `Platform Developer executed SaaS Kill-Switch on "${blockedAdmin.businessName}" (${blockedAdmin.email}) due to overdue invoice #INV-9201.`,
        createdAt: new Date(Date.now() - 2 * 86400000)
      }
    ]
  });

  // 5. Create Employees under activeAdmin
  const emp1 = await prisma.user.create({
    data: {
      name: 'Sarah Connor',
      email: 'sarah@corporate.com',
      password: empPassword,
      role: 'EMPLOYEE',
      adminId: activeAdmin.id,
      department: 'Supply Chain Operations',
      shiftStart: '09:00',
      shiftEnd: '17:00',
      phone: '+1 (555) 101-2020',
      salary: 4800.00
    }
  });

  const emp2 = await prisma.user.create({
    data: {
      name: 'David Miller',
      email: 'david@corporate.com',
      password: empPassword,
      role: 'EMPLOYEE',
      adminId: activeAdmin.id,
      department: 'Warehouse Management',
      shiftStart: '09:00',
      shiftEnd: '17:00',
      phone: '+1 (555) 303-4040',
      salary: 4200.00
    }
  });

  const emp3 = await prisma.user.create({
    data: {
      name: 'Elena Rostova',
      email: 'elena@corporate.com',
      password: empPassword,
      role: 'EMPLOYEE',
      adminId: activeAdmin.id,
      department: 'Inventory Quality Control',
      shiftStart: '10:00',
      shiftEnd: '18:00',
      phone: '+1 (555) 505-6060',
      salary: 5100.00
    }
  });
  console.log('✔ Seeded 3 Employees for Apex Global Logistics');

  // 6. Create Inventory for activeAdmin
  const inv1 = await prisma.inventory.create({
    data: {
      adminId: activeAdmin.id,
      itemName: 'Industrial Laser Barcode Scanner 2D',
      sku: 'SKU-SCN-2001',
      category: 'Hardware',
      quantity: 18,
      minStockLevel: 5,
      costPrice: 85.00,
      sellingPrice: 145.00,
      lastUpdatedBy: activeAdmin.name
    }
  });

  const inv2 = await prisma.inventory.create({
    data: {
      adminId: activeAdmin.id,
      itemName: 'Direct Thermal Shipping Labels (Box of 5000)',
      sku: 'SKU-LBL-5040',
      category: 'Packaging',
      quantity: 3, // LOW STOCK ALERT! (<= 10)
      minStockLevel: 10,
      costPrice: 22.00,
      sellingPrice: 45.00,
      lastUpdatedBy: activeAdmin.name
    }
  });

  const inv3 = await prisma.inventory.create({
    data: {
      adminId: activeAdmin.id,
      itemName: 'Heavy Duty Packaging Tape 72mm',
      sku: 'SKU-TPE-900',
      category: 'Packaging',
      quantity: 2, // LOW STOCK ALERT! (<= 8)
      minStockLevel: 8,
      costPrice: 4.50,
      sellingPrice: 9.99,
      lastUpdatedBy: activeAdmin.name
    }
  });

  const inv4 = await prisma.inventory.create({
    data: {
      adminId: activeAdmin.id,
      itemName: 'RFID Asset Tracking Pallet Tags (Pack of 100)',
      sku: 'SKU-RFID-100',
      category: 'Hardware',
      quantity: 45,
      minStockLevel: 10,
      costPrice: 40.00,
      sellingPrice: 79.00,
      lastUpdatedBy: activeAdmin.name
    }
  });

  // Inventory Audit Trails
  await prisma.auditTrail.createMany({
    data: [
      {
        adminId: activeAdmin.id,
        action: 'CREATED',
        details: 'Initial bulk inventory intake during system setup.',
        userId: activeAdmin.id,
        inventoryId: inv1.id
      },
      {
        adminId: activeAdmin.id,
        action: 'SOLD/ADJUSTED',
        details: 'Dispatched 7 units for Warehouse B outbound shipment.',
        userId: activeAdmin.id,
        inventoryId: inv2.id
      }
    ]
  });
  console.log('✔ Seeded Inventory & Audit Trails');

  // 7. Seed Attendance records for today & yesterday
  const today = new Date();
  today.setHours(9, 5, 0, 0); // Sarah: Present at 9:05

  const todayLate = new Date();
  todayLate.setHours(9, 45, 0, 0); // David: Late at 9:45

  await prisma.attendance.create({
    data: {
      userId: emp1.id,
      adminId: activeAdmin.id,
      date: new Date(),
      checkIn: today,
      status: 'Present',
      notes: 'On time check-in'
    }
  });

  await prisma.attendance.create({
    data: {
      userId: emp2.id,
      adminId: activeAdmin.id,
      date: new Date(),
      checkIn: todayLate,
      status: 'Late',
      notes: 'Traffic delay on highway'
    }
  });

  // Yesterday complete attendance record
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yIn = new Date(yesterday);
  yIn.setHours(8, 58, 0, 0);
  const yOut = new Date(yesterday);
  yOut.setHours(17, 12, 0, 0);

  await prisma.attendance.create({
    data: {
      userId: emp1.id,
      adminId: activeAdmin.id,
      date: yesterday,
      checkIn: yIn,
      checkOut: yOut,
      totalHours: 8.23,
      status: 'Present'
    }
  });

  // 8. Seed Leave Request
  await prisma.leaveRequest.create({
    data: {
      userId: emp3.id,
      adminId: activeAdmin.id,
      reason: 'Attending annual logistics & supply chain conference.',
      startDate: new Date(Date.now() + 86400000 * 3),
      endDate: new Date(Date.now() + 86400000 * 5),
      status: 'Pending'
    }
  });

  console.log('=======================================================');
  console.log('🎉 Seed Completed Successfully!');
  console.log('Demo Credentials:');
  console.log('1. DEVELOPER (SaaS Platform Owner):');
  console.log('   Email:    developer@saas.com');
  console.log('   Password: Developer123!');
  console.log('');
  console.log('2. ADMIN (Active Client Organization):');
  console.log('   Email:    admin@corporate.com');
  console.log('   Password: Admin123!');
  console.log('');
  console.log('3. ADMIN (Suspended / Blocked by SaaS Kill-Switch):');
  console.log('   Email:    blocked@retail.com');
  console.log('   Password: Admin123!');
  console.log('');
  console.log('4. EMPLOYEE (Apex Global Staff):');
  console.log('   Email:    sarah@corporate.com');
  console.log('   Password: Employee123!');
  console.log('=======================================================');
}

main()
  .catch((e) => {
    console.error('Seed error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
