const jwt = require('jsonwebtoken');
const prisma = require('../config/prisma');

const JWT_SECRET = process.env.JWT_SECRET || 'commercial-saas-super-secret-key-2026';

const authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Unauthorized', message: 'No authentication token provided.' });
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, JWT_SECRET);

    const user = await prisma.user.findUnique({
      where: { id: decoded.id },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        businessName: true,
        adminId: true,
        isBlocked: true,
        shiftStart: true,
        shiftEnd: true,
        subscriptionPlan: true,
        subscriptionEndDate: true
      }
    });

    if (!user) {
      return res.status(401).json({ error: 'Unauthorized', message: 'User account does not exist or has been removed.' });
    }

    req.user = user;
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'TokenExpired', message: 'Session expired. Please log in again.' });
    }
    return res.status(401).json({ error: 'Unauthorized', message: 'Invalid authentication token.' });
  }
};

const requireRole = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        error: 'Forbidden',
        message: `Access denied. Requires one of roles: [${allowedRoles.join(', ')}]. Your role is ${req.user ? req.user.role : 'none'}.`
      });
    }
    next();
  };
};

module.exports = { authenticate, requireRole, JWT_SECRET };
