/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#0F172A', // Slate / Dark Blue
          50: '#F8FAFC',
          100: '#F1F5F9',
          200: '#E2E8F0',
          700: '#334155',
          800: '#1E293B',
          900: '#0F172A',
        },
        sidebar: '#1E293B',    // Lighter Slate
        success: {
          DEFAULT: '#10B981', // Vibrant Emerald Green
          hover: '#059669',
          light: '#D1FAE5',
        },
        warning: {
          DEFAULT: '#F59E0B', // Soft Amber
          hover: '#D97706',
          light: '#FEF3C7',
        },
        danger: {
          DEFAULT: '#EF4444',
          hover: '#DC2626',
          light: '#FEE2E2',
        }
      }
    },
  },
  plugins: [],
}
