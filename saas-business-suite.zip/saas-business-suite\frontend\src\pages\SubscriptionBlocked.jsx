import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ShieldAlert, AlertTriangle, PhoneCall, Mail, ArrowRight, LogOut, RefreshCw } from 'lucide-react';

export default function SubscriptionBlocked() {
  const { logout } = useAuth();
  const navigate = useNavigate();

  let blockInfo = {
    error: 'Commercial SaaS License Suspended',
    message: 'Your organization access has been restricted due to overdue billing or platform administrative suspension.',
    code: 'SUSPENDED'
  };

  try {
    const cached = sessionStorage.getItem('killSwitchReason');
    if (cached) {
      blockInfo = JSON.parse(cached);
    }
  } catch (e) {
    console.error(e);
  }

  const handleLogout = () => {
    logout();
    sessionStorage.removeItem('killSwitchReason');
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center px-4 sm:px-6 lg:px-8">
      <div className="max-w-xl w-full text-center">
        {/* Kill-Switch Pulsing Visual */}
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-rose-500/10 border border-rose-500/30 text-rose-500 mb-6 shadow-2xl shadow-rose-900/40">
          <ShieldAlert className="w-10 h-10 animate-pulse" />
        </div>

        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-rose-950 text-rose-300 border border-rose-800">
          <AlertTriangle className="w-3.5 h-3.5" /> SaaS Kill-Switch Triggered
        </span>

        <h1 className="mt-4 text-3xl sm:text-4xl font-black text-white tracking-tight">
          {blockInfo.error || 'Access Temporarily Suspended'}
        </h1>

        <p className="mt-4 text-base text-slate-400 leading-relaxed max-w-md mx-auto">
          {blockInfo.message}
        </p>

        {/* Resolution Steps Box */}
        <div className="mt-8 bg-slate-900/90 rounded-2xl border border-slate-800 p-6 text-left shadow-xl">
          <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider mb-3">
            How to Restore Software Access:
          </h3>
          <ul className="space-y-3 text-xs text-slate-300">
            <li className="flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-emerald-400 shrink-0 mt-0.5">1</span>
              <span>Settle any outstanding SaaS subscription invoices or monthly license fees with your provider.</span>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-emerald-400 shrink-0 mt-0.5">2</span>
              <span>Contact the SaaS Platform Developers to unlock and renew your enterprise tenant profile.</span>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-emerald-400 shrink-0 mt-0.5">3</span>
              <span>Once confirmed, all employee attendance logs and inventory data will be instantaneously restored.</span>
            </li>
          </ul>

          <div className="mt-6 pt-5 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-emerald-400" />
              <span>billing@nexussaas.com</span>
            </div>
            <div className="flex items-center gap-2">
              <PhoneCall className="w-4 h-4 text-emerald-400" />
              <span>+1 (800) 555-SAAS</span>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            onClick={() => window.location.reload()}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition border border-slate-700"
          >
            <RefreshCw className="w-4 h-4" /> Check Restoration Status
          </button>

          <button
            onClick={handleLogout}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition shadow-lg shadow-rose-600/20"
          >
            <LogOut className="w-4 h-4" /> Switch / Exit Account
          </button>
        </div>
      </div>
    </div>
  );
}
