const prisma = require('../config/prisma');

/**
 * Submit a Leave Request
 */
const submitLeaveRequest = async (req, res) => {
  const userId = req.user.id;
  const adminId = req.user.adminId;
  const { reason, startDate, endDate } = req.body;

  try {
    if (!reason) {
      return res.status(400).json({ error: 'Please provide a reason for the leave request' });
    }

    const leave = await prisma.leaveRequest.create({
      data: {
        userId,
        adminId,
        reason: reason.trim(),
        startDate: startDate ? new Date(startDate) : new Date(),
        endDate: endDate ? new Date(endDate) : new Date(),
        status: 'Pending'
      }
    });

    res.status(201).json({
      success: true,
      message: 'Leave request submitted successfully. Awaiting Admin review.',
      leave
    });
  } catch (error) {
    console.error('Error submitting leave request:', error);
    res.status(500).json({ error: 'Failed to submit leave request' });
  }
};

/**
 * Get My Leave Requests
 */
const getMyLeaves = async (req, res) => {
  const userId = req.user.id;

  try {
    const leaves = await prisma.leaveRequest.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' }
    });

    res.json({ success: true, leaves });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch leave requests' });
  }
};

/**
 * Get My Employee Profile Details
 */
const getMyDetails = async (req, res) => {
  const userId = req.user.id;

  try {
    const employee = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        shiftStart: true,
        shiftEnd: true,
        department: true,
        phone: true,
        createdAt: true
      }
    });

    // Also fetch business name
    let employerName = 'Corporate Headquarters';
    if (req.user.adminId) {
      const employer = await prisma.user.findUnique({
        where: { id: req.user.adminId },
        select: { businessName: true, name: true }
      });
      if (employer) employerName = employer.businessName || employer.name;
    }

    res.json({
      success: true,
      employee: {
        ...employee,
        employerName
      }
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch employee details' });
  }
};

module.exports = {
  submitLeaveRequest,
  getMyLeaves,
  getMyDetails
};
