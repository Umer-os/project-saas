# NexusSaaS Business Management & Attendance Suite 🚀

> **Production-Grade Commercial SaaS Platform** featuring 3 strictly isolated role dashboards (**Platform Developer**, **Client Admin / Business Owner**, and **Staff Employee**), automated background subscription billing & kill-switch, inventory audit trails, and SheetJS Excel attendance reports.

---

## 🌟 Key Architecture & Capabilities

### 1. 🛡️ Three Distinct Roles & Isolated Workspaces
| Role | Portal Route | Primary Capabilities & Authorities | Restrictions & Security Guardrails |
| :--- | :--- | :--- | :--- |
| **DEVELOPER** *(SaaS Owner)* | `/developer/dashboard` | Platform metrics, tenant oversight, **SaaS Kill-Switch** (block/unblock clients), subscription renewal (+30/90/365 days), system audit logs, and on-demand cron sweeps. | **Strict Limit:** Maximum of **2 Developers** globally across the platform. System rejects a 3rd registration. |
| **ADMIN** *(Business Client)* | `/admin/dashboard` | Live attendance tracking, shift definitions, manual punch adjustments/overrides, **SheetJS `.xlsx` Excel export**, dynamic inventory search/CRUD, audit trails, staff directory, and leave approvals. | Subject to **SaaS Kill-Switch** & automated subscription expiry. If blocked by developer or overdue, access is locked across the entire tenant. |
| **EMPLOYEE** *(Staff Member)* | `/employee/dashboard` | Self-Service Terminal with live clock punch-in/out, automatic late detection based on shift, attendance history, and leave requests. | Isolated exclusively to their personal records. Optional **Office Network / Geo-fencing** validation. |

---

### 2. ⚡ The SaaS Kill-Switch & Automated Subscription Engine
- **Manual Kill-Switch:** A Developer can instantly toggle an Admin's `isBlocked` flag. When blocked, neither the Admin nor their staff can log in or create accounts.
- **Automated Expiry (`node-cron`):** A daily background cron job sweeps the database. Any Admin whose `subscriptionEndDate` has passed is automatically marked `isBlocked = true` with a permanent record in `SystemAuditLog`.
- **Interception Screen (`/subscription-blocked`):** Non-paying clients and their employees receive an immediate `403 Forbidden` response and are routed to a branded suspension screen with provider contact details.

---

### 3. 📊 Inventory Management with Audit Trail
- **Live Search & Filter:** Instant dynamic search by Item Name, SKU, or Category as the user types.
- **Stock Tracking:** Soft-amber warning badges automatically trigger whenever `quantity <= minStockLevel`.
- **Automatic Audit Trail:** Every stock modification (creation, restock, dispatch, price edit) records a permanent entry into `AuditTrail` capturing the exact changes, timestamp, and *Last Updated By* user name.

---

### 4. 🕒 Attendance Management & SheetJS Export
- **Live Clock Terminal:** Records exact check-in and check-out timestamps, calculates net hours worked, and flags late arrivals beyond the 10-minute grace window.
- **Manual Adjustments:** Admins can adjust punch times, correct logs, or delete duplicates.
- **Instant Excel Export:** Admins select any date range (`startDate` to `endDate`) and generate a formatted `.xlsx` workbook via SheetJS with a single click.

---

### 5. 🔑 Token-Based Password Recovery Flow
- Secure `crypto.randomBytes(32)` single-use tokens hashed with SHA-256 and stored with a 15-minute expiration timestamp.
- Dedicated `/forgot-password` and `/reset-password` UI workflows.

---

## 🚀 Quick Start Guide

### 1. Default Demo Credentials
Use these pre-seeded accounts to test all roles immediately:

| Role | Email | Password | Details |
| :--- | :--- | :--- | :--- |
| **Developer (SaaS Owner)** | `developer@saas.com` | `Developer123!` | Master platform command (Slot 1/2) |
| **Active Client Admin** | `admin@corporate.com` | `Admin123!` | Apex Global Logistics (Active 30 days) |
| **Suspended Client Admin** | `blocked@retail.com` | `Admin123!` | Test the **SaaS Kill-Switch** screen |
| **Staff Employee** | `sarah@corporate.com` | `Employee123!` | Dedicated terminal & check-in punch |

*(Tip: The login page includes 1-click quick credentials switcher buttons for rapid testing.)*

---

### 2. Starting the Services

#### Backend (Node.js & Express)
```bash
cd backend
npm install
npx prisma db push
node src/seed.js        # Seeds demo users, inventory & logs
node src/server.js       # Starts API server on port 5000
```

#### Frontend (React + Vite + Tailwind CSS)
```bash
cd frontend
npm install
npm run dev              # Starts Vite dev server on port 5173
```

- **Frontend App:** [http://localhost:5173](http://localhost:5173)
- **Backend API:** [http://localhost:5000](http://localhost:5000)
- **Health Check:** [http://localhost:5000/api/health](http://localhost:5000/api/health)

---

### 3. Running the Automated Test Suite
To execute the automated test suite verifying all 8 core features (15 passing assertions):
```bash
cd backend
node test-suite.js
```
