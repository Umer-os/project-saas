const express = require('express');
const router = express.Router();
const {
  getAdminDashboardStats,
  getEmployees,
  createEmployee,
  updateEmployee,
  deleteEmployee,
  getLeaveRequests,
  updateLeaveStatus
} = require('../controllers/adminController');
const { getFinancialAnalytics, recordSale } = require('../controllers/financialController');
const { getPayrollSummary } = require('../controllers/payrollController');
const { authenticate, requireRole } = require('../middleware/auth');
const { verifyLicenseStatus } = require('../middleware/licenseCheck');

// Require authentication, ADMIN role, and active license (Kill-Switch check)
router.use(authenticate, requireRole('ADMIN'), verifyLicenseStatus);

// Core Dashboard & Employees
router.get('/stats', getAdminDashboardStats);
router.get('/employees', getEmployees);
router.post('/employees', createEmployee);
router.put('/employees/:id', updateEmployee);
router.delete('/employees/:id', deleteEmployee);

// Leave Requests
router.get('/leaves', getLeaveRequests);
router.put('/leaves/:id/status', updateLeaveStatus);

// Profit & Loss, Sales Financials
router.get('/financials', getFinancialAnalytics);
router.post('/sales', recordSale);

// Payroll & Performance
router.get('/payroll', getPayrollSummary);

module.exports = router;
