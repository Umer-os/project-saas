import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to attach JWT token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor to handle Kill-Switch 403 & 401 Session Expiry
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      const { status, data } = error.response;

      // SaaS Kill-Switch Detection
      if (status === 403 && (data.code === 'SUSPENDED' || data.code === 'EXPIRED' || data.code === 'COMPANY_SUSPENDED' || data.code === 'BLOCKED')) {
        // Store block details in sessionStorage so SubscriptionBlocked page can display exact reason
        sessionStorage.setItem('killSwitchReason', JSON.stringify({
          error: data.error,
          message: data.message,
          code: data.code
        }));

        if (!window.location.pathname.includes('/subscription-blocked')) {
          window.location.href = '/subscription-blocked';
        }
      }

      if (status === 401 && !window.location.pathname.includes('/login')) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

export default api;
