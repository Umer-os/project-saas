const prisma = require('../config/prisma');

/**
 * Get Payroll & Performance Analytics for Staff
 */
const getPayrollSummary = async (req, res) => {
  const adminId = req.user.id;
  const { month, year } = req.query;

  try {
    const targetYear = year ? parseInt(year) : new Date().getFullYear();
    const targetMonth = month !== undefined ? parseInt(month) : new Date().getMonth(); // 0-indexed

    const startOfMonth = new Date(targetYear, targetMonth, 1);
    const endOfMonth = new Date(targetYear, targetMonth + 1, 0, 23, 59, 59, 999);

    const employees = await prisma.user.findMany({
      where: { role: 'EMPLOYEE', adminId },
      select: {
        id: true,
        name: true,
        email: true,
        department: true,
        salary: true,
        shiftStart: true,
        shiftEnd: true
      }
    });

    const payrollData = await Promise.all(
      employees.map(async (emp) => {
        const attendances = await prisma.attendance.findMany({
          where: {
            userId: emp.id,
            date: { gte: startOfMonth, lte: endOfMonth }
          }
        });

        const totalDaysPresent = attendances.filter(a => a.status === 'Present' || a.status === 'Late').length;
        const totalLateDays = attendances.filter(a => a.status === 'Late').length;
        const totalHoursWorked = parseFloat(
          attendances.reduce((acc, a) => acc + (a.totalHours || 0), 0).toFixed(2)
        );

        // Standard working days in month ~ 22 days (8 hours/day = 176 hours)
        const expectedHours = 22 * 8;
        const attendanceRate = expectedHours > 0
          ? Math.min(100, parseFloat(((totalHoursWorked / expectedHours) * 100).toFixed(1)))
          : 0;

        // Base monthly salary
        const baseSalary = emp.salary || 3500;

        // Deductions: $20 penalty for each late day beyond 2 grace occurrences
        const excessiveLateDays = Math.max(0, totalLateDays - 2);
        const lateDeduction = excessiveLateDays * 20;

        // Net payout
        const netSalary = Math.max(0, parseFloat((baseSalary - lateDeduction).toFixed(2)));

        return {
          employeeId: emp.id,
          name: emp.name,
          email: emp.email,
          department: emp.department,
          baseSalary,
          totalDaysPresent,
          totalLateDays,
          totalHoursWorked,
          attendanceRate,
          excessiveLateDays,
          lateDeduction,
          netSalary,
          status: 'Processed'
        };
      })
    );

    const totalPayrollDisbursement = payrollData.reduce((acc, p) => acc + p.netSalary, 0);

    res.json({
      success: true,
      period: {
        month: targetMonth + 1,
        year: targetYear,
        monthName: startOfMonth.toLocaleString('default', { month: 'long' })
      },
      summary: {
        totalStaffCount: employees.length,
        totalPayrollDisbursement: parseFloat(totalPayrollDisbursement.toFixed(2)),
        averageAttendanceRate: payrollData.length > 0
          ? parseFloat((payrollData.reduce((acc, p) => acc + p.attendanceRate, 0) / payrollData.length).toFixed(1))
          : 0
      },
      payroll: payrollData
    });
  } catch (error) {
    console.error('Payroll summary error:', error);
    res.status(500).json({ error: 'Failed to generate payroll calculation' });
  }
};

module.exports = {
  getPayrollSummary
};
