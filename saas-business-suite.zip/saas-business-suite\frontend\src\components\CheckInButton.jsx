import React, { useState, useEffect } from 'react';
import { Clock, CheckCircle2, LogOut, AlertCircle, Wifi, ShieldCheck } from 'lucide-react';
import api from '../services/api';

export default function CheckInButton({ onAttendanceUpdated, todayRecord, shiftInfo }) {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [enforceGeofence, setEnforceGeofence] = useState(false);

  // Live Clock Tick
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const isCheckedIn = Boolean(todayRecord && todayRecord.checkIn);
  const isCheckedOut = Boolean(todayRecord && todayRecord.checkOut);

  const handleAttendance = async (actionType) => {
    setLoading(true);
    setMessage(null);

    try {
      const endpoint = actionType === 'in' ? '/attendance/check-in' : '/attendance/check-out';
      const headers = {};
      if (enforceGeofence) {
        headers['x-enforce-geofence'] = 'true';
      }

      const response = await api.post(endpoint, {}, { headers });

      setMessage({
        type: 'success',
        text: response.data.message
      });

      if (onAttendanceUpdated) {
        onAttendanceUpdated();
      }
    } catch (err) {
      const errorMsg = err.response?.data?.message || err.response?.data?.error || 'Attendance action failed';
      setMessage({
        type: 'error',
        text: errorMsg
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 sm:p-8">
      {/* Top Banner with Clock & Shift */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Live Attendance Terminal</span>
          </div>
          <div className="text-3xl sm:text-4xl font-extrabold text-slate-900 mt-1 tracking-tight">
            {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            {currentTime.toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' })}
          </p>
        </div>

        <div className="bg-slate-50 rounded-xl p-4 border border-slate-200/70 sm:text-right">
          <div className="text-xs text-slate-500 font-medium">Assigned Shift Timing</div>
          <div className="text-sm font-bold text-slate-800 mt-0.5">
            {shiftInfo?.shiftStart || '09:00'} - {shiftInfo?.shiftEnd || '17:00'}
          </div>
          <div className="text-xs text-slate-500 mt-0.5">
            Department: <span className="font-medium text-slate-700">{shiftInfo?.department || 'Operations'}</span>
          </div>
        </div>
      </div>

      {/* Today's Status Overview */}
      <div className="my-6 p-4 rounded-xl bg-slate-50/70 border border-slate-100 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className={`w-3 h-3 rounded-full ${
            isCheckedOut
              ? 'bg-slate-400'
              : isCheckedIn
              ? 'bg-emerald-500 ring-4 ring-emerald-100'
              : 'bg-amber-400 ring-4 ring-amber-100'
          }`} />
          <span className="text-sm font-semibold text-slate-700">
            Today's Log Status:
          </span>
          <span className={`text-xs px-2.5 py-1 rounded-md font-bold uppercase tracking-wider ${
            isCheckedOut
              ? 'bg-slate-200 text-slate-700'
              : isCheckedIn
              ? 'bg-emerald-100 text-emerald-800'
              : 'bg-amber-100 text-amber-800'
          }`}>
            {isCheckedOut ? 'Shift Completed' : isCheckedIn ? (todayRecord?.status || 'Present') : 'Not Checked In'}
          </span>
        </div>

        {todayRecord?.checkIn && (
          <div className="text-xs text-slate-500">
            Checked in at: <span className="font-semibold text-slate-800">{new Date(todayRecord.checkIn).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            {todayRecord.checkOut && (
              <> | Checked out at: <span className="font-semibold text-slate-800">{new Date(todayRecord.checkOut).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span></>
            )}
            {todayRecord.totalHours ? (
              <span className="ml-2 font-bold text-emerald-600">({todayRecord.totalHours} hrs worked)</span>
            ) : null}
          </div>
        )}
      </div>

      {/* Network / Geo-fencing Security Indicator */}
      <div className="mb-6 flex items-center justify-between p-3 rounded-lg bg-slate-100/60 border border-slate-200 text-xs text-slate-600">
        <div className="flex items-center gap-2">
          <Wifi className="w-4 h-4 text-emerald-600" />
          <span>Office Network & Geo-Fence Validation:</span>
          <span className="font-medium text-slate-800">{enforceGeofence ? 'Strict Geofence Active' : 'Automatic Corporate IP Verified'}</span>
        </div>
        <button
          type="button"
          onClick={() => setEnforceGeofence(!enforceGeofence)}
          className={`px-2 py-0.5 rounded text-[11px] font-medium transition ${
            enforceGeofence ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
          }`}
        >
          {enforceGeofence ? 'Enforced' : 'Standard Mode'}
        </button>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* CHECK-IN BUTTON */}
        <button
          onClick={() => handleAttendance('in')}
          disabled={loading || isCheckedIn}
          className={`flex items-center justify-center gap-3 py-4 px-6 rounded-xl font-bold text-base transition-all shadow-sm ${
            isCheckedIn
              ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
              : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-500/20 hover:shadow-emerald-500/30 active:scale-[0.99]'
          }`}
        >
          <CheckCircle2 className="w-5 h-5" />
          <span>{loading ? 'Processing...' : isCheckedIn ? 'Checked In Today' : 'Punch Check-In'}</span>
        </button>

        {/* CHECK-OUT BUTTON */}
        <button
          onClick={() => handleAttendance('out')}
          disabled={loading || !isCheckedIn || isCheckedOut}
          className={`flex items-center justify-center gap-3 py-4 px-6 rounded-xl font-bold text-base transition-all shadow-sm ${
            !isCheckedIn || isCheckedOut
              ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
              : 'bg-slate-800 hover:bg-slate-900 text-white shadow-slate-900/20 hover:shadow-slate-900/30 active:scale-[0.99]'
          }`}
        >
          <LogOut className="w-5 h-5" />
          <span>{loading ? 'Processing...' : isCheckedOut ? 'Checked Out' : 'Punch Check-Out'}</span>
        </button>
      </div>

      {/* Alerts / Feedback Message */}
      {message && (
        <div className={`mt-4 p-4 rounded-xl flex items-start gap-3 text-sm ${
          message.type === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-rose-50 text-rose-800 border border-rose-200'
        }`}>
          {message.type === 'success' ? <ShieldCheck className="w-5 h-5 shrink-0 text-emerald-600 mt-0.5" /> : <AlertCircle className="w-5 h-5 shrink-0 text-rose-600 mt-0.5" />}
          <div>{message.text}</div>
        </div>
      )}
    </div>
  );
}
