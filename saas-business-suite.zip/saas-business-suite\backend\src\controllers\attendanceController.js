const prisma = require('../config/prisma');

/**
 * Employee Check-In Action
 */
const checkIn = async (req, res) => {
  const userId = req.user.id;
  const adminId = req.user.adminId || null;

  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // Check if an entry for today already exists
    const existingEntry = await prisma.attendance.findFirst({
      where: {
        userId,
        date: {
          gte: today,
          lt: tomorrow
        }
      }
    });

    if (existingEntry && existingEntry.checkIn) {
      return res.status(400).json({
        error: 'Already Checked In',
        message: `You have already checked in today at ${new Date(existingEntry.checkIn).toLocaleTimeString()}.`
      });
    }

    const now = new Date();

    // Determine if employee is Late based on assigned shiftStart (e.g. "09:00")
    let status = 'Present';
    if (req.user.shiftStart) {
      const [shiftHour, shiftMinute] = req.user.shiftStart.split(':').map(Number);
      const shiftStartTime = new Date();
      shiftStartTime.setHours(shiftHour, shiftMinute, 0, 0);

      // Grace period of 10 minutes
      const graceTime = new Date(shiftStartTime.getTime() + 10 * 60 * 1000);
      if (now > graceTime) {
        status = 'Late';
      }
    }

    let record;
    if (existingEntry) {
      record = await prisma.attendance.update({
        where: { id: existingEntry.id },
        data: {
          checkIn: now,
          status,
          ipAddress: req.ip || req.connection.remoteAddress
        }
      });
    } else {
      record = await prisma.attendance.create({
        data: {
          userId,
          adminId,
          date: today,
          checkIn: now,
          status,
          ipAddress: req.ip || req.connection.remoteAddress
        }
      });
    }

    res.status(201).json({
      success: true,
      message: `Checked in successfully at ${now.toLocaleTimeString()}! Status: ${status}`,
      attendance: record
    });
  } catch (error) {
    console.error('Check-in error:', error);
    res.status(500).json({ error: 'Check-in failed' });
  }
};

/**
 * Employee Check-Out Action
 */
const checkOut = async (req, res) => {
  const userId = req.user.id;

  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // Find today's active check-in record
    const record = await prisma.attendance.findFirst({
      where: {
        userId,
        date: {
          gte: today,
          lt: tomorrow
        },
        checkIn: { not: null }
      }
    });

    if (!record) {
      return res.status(400).json({
        error: 'No Active Check-In',
        message: 'No check-in record found for today. Please check in first.'
      });
    }

    if (record.checkOut) {
      return res.status(400).json({
        error: 'Already Checked Out',
        message: `You have already checked out today at ${new Date(record.checkOut).toLocaleTimeString()}.`
      });
    }

    const now = new Date();
    const durationMs = now.getTime() - new Date(record.checkIn).getTime();
    const totalHours = parseFloat((durationMs / (1000 * 60 * 60)).toFixed(2));

    const updatedRecord = await prisma.attendance.update({
      where: { id: record.id },
      data: {
        checkOut: now,
        totalHours
      }
    });

    res.json({
      success: true,
      message: `Checked out successfully at ${now.toLocaleTimeString()}! Total hours logged: ${totalHours} hrs.`,
      attendance: updatedRecord
    });
  } catch (error) {
    console.error('Check-out error:', error);
    res.status(500).json({ error: 'Check-out failed' });
  }
};

/**
 * Get Attendance Records for Admin (with filters: date range, employee search)
 */
const getAdminAttendance = async (req, res) => {
  const adminId = req.user.id;
  const { startDate, endDate, userId } = req.query;

  try {
    const whereClause = { adminId };

    if (startDate && endDate) {
      const start = new Date(startDate);
      start.setHours(0, 0, 0, 0);
      const end = new Date(endDate);
      end.setHours(23, 59, 59, 999);
      whereClause.date = { gte: start, lte: end };
    }

    if (userId) {
      whereClause.userId = userId;
    }

    const records = await prisma.attendance.findMany({
      where: whereClause,
      include: {
        user: {
          select: { name: true, email: true, department: true, shiftStart: true, shiftEnd: true }
        }
      },
      orderBy: { date: 'desc' }
    });

    res.json({ success: true, count: records.length, records });
  } catch (error) {
    console.error('Error fetching admin attendance:', error);
    res.status(500).json({ error: 'Failed to fetch attendance logs' });
  }
};

/**
 * Admin Manual Override / Adjustment of Attendance
 */
const overrideAttendance = async (req, res) => {
  const adminId = req.user.id;
  const { id } = req.params;
  const { checkIn, checkOut, status, notes } = req.body;

  try {
    const existing = await prisma.attendance.findFirst({
      where: { id, adminId }
    });

    if (!existing) {
      return res.status(404).json({ error: 'Attendance record not found' });
    }

    const newCheckIn = checkIn ? new Date(checkIn) : existing.checkIn;
    const newCheckOut = checkOut ? new Date(checkOut) : existing.checkOut;

    let totalHours = existing.totalHours;
    if (newCheckIn && newCheckOut) {
      const diffMs = new Date(newCheckOut).getTime() - new Date(newCheckIn).getTime();
      totalHours = parseFloat((diffMs / (1000 * 60 * 60)).toFixed(2));
    }

    const updated = await prisma.attendance.update({
      where: { id },
      data: {
        checkIn: newCheckIn,
        checkOut: newCheckOut,
        status: status || existing.status,
        totalHours: totalHours >= 0 ? totalHours : 0,
        notes: notes || existing.notes,
        overriddenBy: req.user.name
      }
    });

    res.json({
      success: true,
      message: 'Attendance record manually adjusted successfully.',
      record: updated
    });
  } catch (error) {
    console.error('Error adjusting attendance:', error);
    res.status(500).json({ error: 'Failed to adjust attendance' });
  }
};

/**
 * Delete or correct duplicate attendance logs
 */
const deleteAttendance = async (req, res) => {
  const adminId = req.user.id;
  const { id } = req.params;

  try {
    const existing = await prisma.attendance.findFirst({
      where: { id, adminId }
    });

    if (!existing) {
      return res.status(404).json({ error: 'Record not found or unauthorized' });
    }

    await prisma.attendance.delete({ where: { id } });

    res.json({ success: true, message: 'Attendance log entry removed successfully' });
  } catch (error) {
    console.error('Error deleting attendance:', error);
    res.status(500).json({ error: 'Failed to delete attendance log' });
  }
};

/**
 * Get Today's Status for Logged-In Employee
 */
const getMyTodayAttendance = async (req, res) => {
  const userId = req.user.id;

  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const record = await prisma.attendance.findFirst({
      where: {
        userId,
        date: {
          gte: today,
          lt: tomorrow
        }
      }
    });

    res.json({ success: true, record });
  } catch (error) {
    res.status(500).json({ error: 'Failed to retrieve attendance status' });
  }
};

/**
 * Get Attendance History for Logged-In Employee
 */
const getMyAttendanceHistory = async (req, res) => {
  const userId = req.user.id;

  try {
    const history = await prisma.attendance.findMany({
      where: { userId },
      orderBy: { date: 'desc' },
      take: 60
    });

    res.json({ success: true, history });
  } catch (error) {
    res.status(500).json({ error: 'Failed to retrieve attendance history' });
  }
};

module.exports = {
  checkIn,
  checkOut,
  getAdminAttendance,
  overrideAttendance,
  deleteAttendance,
  getMyTodayAttendance,
  getMyAttendanceHistory
};
