const prisma = require('../config/prisma');

/**
 * Get all inventory items for the Admin organization with search & filter
 */
const getInventory = async (req, res) => {
  const adminId = req.user.id;
  const { search, lowStockOnly, category } = req.query;

  try {
    const whereClause = { adminId };

    if (search) {
      whereClause.OR = [
        { itemName: { contains: search } },
        { sku: { contains: search } },
        { category: { contains: search } }
      ];
    }

    if (category && category !== 'All') {
      whereClause.category = category;
    }

    let items = await prisma.inventory.findMany({
      where: whereClause,
      include: {
        auditTrails: {
          orderBy: { createdAt: 'desc' },
          take: 3,
          include: {
            user: { select: { name: true } }
          }
        }
      },
      orderBy: { updatedAt: 'desc' }
    });

    if (lowStockOnly === 'true') {
      items = items.filter(item => item.quantity <= item.minStockLevel);
    }

    res.json({ success: true, count: items.length, items });
  } catch (error) {
    console.error('Error fetching inventory:', error);
    res.status(500).json({ error: 'Failed to fetch inventory' });
  }
};

/**
 * Add a new inventory item
 */
const createInventoryItem = async (req, res) => {
  const adminId = req.user.id;
  const { itemName, sku, category, quantity, minStockLevel, costPrice, sellingPrice } = req.body;

  try {
    if (!itemName || !sku) {
      return res.status(400).json({ error: 'Item name and SKU are required' });
    }

    const existingSku = await prisma.inventory.findUnique({
      where: { sku: sku.trim().toUpperCase() }
    });

    if (existingSku) {
      return res.status(400).json({ error: `SKU "${sku}" is already in use.` });
    }

    const item = await prisma.inventory.create({
      data: {
        adminId,
        itemName: itemName.trim(),
        sku: sku.trim().toUpperCase(),
        category: category || 'General',
        quantity: parseInt(quantity) || 0,
        minStockLevel: parseInt(minStockLevel) || 5,
        costPrice: parseFloat(costPrice) || 0,
        sellingPrice: parseFloat(sellingPrice) || 0,
        lastUpdatedBy: req.user.name
      }
    });

    // Record Audit Trail
    await prisma.auditTrail.create({
      data: {
        adminId,
        action: 'CREATED',
        details: `Initial entry: Created item "${item.itemName}" (SKU: ${item.sku}) with quantity ${item.quantity}. Cost: $${item.costPrice}, Selling: $${item.sellingPrice}.`,
        userId: req.user.id,
        inventoryId: item.id
      }
    });

    res.status(201).json({ success: true, message: 'Item created successfully', item });
  } catch (error) {
    console.error('Error creating inventory item:', error);
    res.status(500).json({ error: 'Failed to create inventory item' });
  }
};

/**
 * Update an inventory item (Quantity adjustment or detail changes)
 */
const updateInventoryItem = async (req, res) => {
  const adminId = req.user.id;
  const { id } = req.params;
  const { itemName, category, quantity, minStockLevel, costPrice, sellingPrice, changeReason } = req.body;

  try {
    const existing = await prisma.inventory.findFirst({
      where: { id, adminId }
    });

    if (!existing) {
      return res.status(404).json({ error: 'Inventory item not found' });
    }

    const oldQty = existing.quantity;
    const newQty = quantity !== undefined ? parseInt(quantity) : oldQty;
    const diff = newQty - oldQty;

    const updated = await prisma.inventory.update({
      where: { id },
      data: {
        itemName: itemName !== undefined ? itemName.trim() : undefined,
        category: category !== undefined ? category : undefined,
        quantity: newQty,
        minStockLevel: minStockLevel !== undefined ? parseInt(minStockLevel) : undefined,
        costPrice: costPrice !== undefined ? parseFloat(costPrice) : undefined,
        sellingPrice: sellingPrice !== undefined ? parseFloat(sellingPrice) : undefined,
        lastUpdatedBy: req.user.name
      }
    });

    // Audit Trail logging
    let action = 'UPDATED';
    let details = `Updated by ${req.user.name}.`;
    if (diff !== 0) {
      action = diff > 0 ? 'RESTOCKED' : 'SOLD/ADJUSTED';
      details = `Stock changed from ${oldQty} to ${newQty} (${diff > 0 ? '+' : ''}${diff} units). Reason: ${changeReason || 'Direct update'}. Updated by ${req.user.name}.`;
    } else {
      details = `Modified attributes for item "${updated.itemName}". Updated by ${req.user.name}.`;
    }

    await prisma.auditTrail.create({
      data: {
        adminId,
        action,
        details,
        userId: req.user.id,
        inventoryId: updated.id
      }
    });

    res.json({ success: true, message: 'Inventory updated successfully', item: updated });
  } catch (error) {
    console.error('Error updating inventory item:', error);
    res.status(500).json({ error: 'Failed to update inventory item' });
  }
};

/**
 * Delete an inventory item
 */
const deleteInventoryItem = async (req, res) => {
  const adminId = req.user.id;
  const { id } = req.params;

  try {
    const existing = await prisma.inventory.findFirst({
      where: { id, adminId }
    });

    if (!existing) {
      return res.status(404).json({ error: 'Item not found' });
    }

    // Record audit trail before deletion
    await prisma.auditTrail.create({
      data: {
        adminId,
        action: 'DELETED',
        details: `Deleted item "${existing.itemName}" (SKU: ${existing.sku}) with final stock ${existing.quantity} units by ${req.user.name}.`,
        userId: req.user.id,
        inventoryId: null
      }
    });

    await prisma.inventory.delete({ where: { id } });

    res.json({ success: true, message: `Item "${existing.itemName}" removed from inventory` });
  } catch (error) {
    console.error('Error deleting inventory item:', error);
    res.status(500).json({ error: 'Failed to delete inventory item' });
  }
};

/**
 * Get item audit history
 */
const getItemAuditHistory = async (req, res) => {
  const adminId = req.user.id;
  const { id } = req.params;

  try {
    const trails = await prisma.auditTrail.findMany({
      where: {
        adminId,
        ...(id ? { inventoryId: id } : {})
      },
      include: {
        user: { select: { name: true, email: true } },
        inventory: { select: { itemName: true, sku: true } }
      },
      orderBy: { createdAt: 'desc' },
      take: 50
    });

    res.json({ success: true, trails });
  } catch (error) {
    console.error('Error fetching audit trail:', error);
    res.status(500).json({ error: 'Failed to fetch inventory audit history' });
  }
};

module.exports = {
  getInventory,
  createInventoryItem,
  updateInventoryItem,
  deleteInventoryItem,
  getItemAuditHistory
};
