const prisma = require('../config/prisma');

const verifyLicenseStatus = async (req, res, next) => {
  try {
    const user = req.user;
    if (!user) {
      return res.status(401).json({ error: 'Unauthorized', message: 'User not authenticated' });
    }

    // DEVELOPER has unconditional master platform access
    if (user.role === 'DEVELOPER') {
      return next();
    }

    // ADMIN verification
    if (user.role === 'ADMIN') {
      if (user.isBlocked) {
        return res.status(403).json({
          error: 'Account Suspended',
          code: 'SUSPENDED',
          message: 'Your software license access has been restricted by the SaaS platform administrator due to pending billing or policy restrictions.'
        });
      }

      // Check subscription expiry date
      if (user.subscriptionEndDate && new Date(user.subscriptionEndDate) < new Date()) {
        // Automatically persist blocked state
        await prisma.user.update({
          where: { id: user.id },
          data: { isBlocked: true }
        });

        return res.status(403).json({
          error: 'Subscription Expired',
          code: 'EXPIRED',
          message: 'Your SaaS subscription has expired. Please contact your SaaS provider to renew your license.'
        });
      }

      return next();
    }

    // EMPLOYEE verification
    if (user.role === 'EMPLOYEE') {
      // Check employee personal status
      if (user.isBlocked) {
        return res.status(403).json({
          error: 'Account Deactivated',
          code: 'DEACTIVATED',
          message: 'Your employee profile has been deactivated by your company administrator.'
        });
      }

      // Check organization (Admin) parent status
      if (user.adminId) {
        const organizationAdmin = await prisma.user.findUnique({
          where: { id: user.adminId },
          select: { isBlocked: true, subscriptionEndDate: true, businessName: true }
        });

        if (organizationAdmin) {
          if (organizationAdmin.isBlocked || (organizationAdmin.subscriptionEndDate && new Date(organizationAdmin.subscriptionEndDate) < new Date())) {
            return res.status(403).json({
              error: 'Company Subscription Suspended',
              code: 'COMPANY_SUSPENDED',
              message: `Access for ${organizationAdmin.businessName || 'your organization'} is currently suspended due to pending subscription billing. Please consult your business administrator.`
            });
          }
        }
      }

      return next();
    }

    next();
  } catch (error) {
    console.error('License check error:', error);
    return res.status(500).json({ error: 'Server Error during license verification' });
  }
};

module.exports = { verifyLicenseStatus };
