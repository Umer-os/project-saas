const prisma = require('../config/prisma');
const { checkSubscriptionExpiryNow } = require('../jobs/subscriptionCron');

/**
 * Get SaaS Platform Overview Stats for Developers
 */
const getPlatformStats = async (req, res) => {
  try {
    const totalAdmins = await prisma.user.count({ where: { role: 'ADMIN' } });
    const blockedAdmins = await prisma.user.count({ where: { role: 'ADMIN', isBlocked: true } });
    const activeAdmins = totalAdmins - blockedAdmins;
    const totalEmployees = await prisma.user.count({ where: { role: 'EMPLOYEE' } });
    const totalDevelopers = await prisma.user.count({ where: { role: 'DEVELOPER' } });
    const totalInventoryItems = await prisma.inventory.count();

    // Expiring within 7 days
    const sevenDaysFromNow = new Date();
    sevenDaysFromNow.setDate(sevenDaysFromNow.getDate() + 7);
    const expiringSoon = await prisma.user.count({
      where: {
        role: 'ADMIN',
        isBlocked: false,
        subscriptionEndDate: {
          lte: sevenDaysFromNow,
          gte: new Date()
        }
      }
    });

    res.json({
      success: true,
      stats: {
        totalAdmins,
        activeAdmins,
        blockedAdmins,
        totalEmployees,
        totalDevelopers,
        developerSlotsRemaining: Math.max(0, 2 - totalDevelopers),
        totalInventoryItems,
        expiringSoon
      }
    });
  } catch (error) {
    console.error('Error fetching platform stats:', error);
    res.status(500).json({ error: 'Failed to retrieve SaaS platform analytics' });
  }
};

/**
 * Get list of all client businesses (Admins) with rich details
 */
const getAllClients = async (req, res) => {
  try {
    const admins = await prisma.user.findMany({
      where: { role: 'ADMIN' },
      select: {
        id: true,
        name: true,
        email: true,
        businessName: true,
        phone: true,
        isBlocked: true,
        subscriptionPlan: true,
        subscriptionEndDate: true,
        createdAt: true,
        updatedAt: true
      },
      orderBy: { createdAt: 'desc' }
    });

    // Enrich with employee count and inventory count for each admin
    const enrichedClients = await Promise.all(
      admins.map(async (admin) => {
        const employeeCount = await prisma.user.count({
          where: { role: 'EMPLOYEE', adminId: admin.id }
        });
        const inventoryCount = await prisma.inventory.count({
          where: { adminId: admin.id }
        });

        // Determine subscription health status
        let subStatus = 'Active';
        if (admin.isBlocked) {
          subStatus = 'Blocked';
        } else if (admin.subscriptionEndDate && new Date(admin.subscriptionEndDate) < new Date()) {
          subStatus = 'Expired';
        }

        return {
          ...admin,
          employeeCount,
          inventoryCount,
          subStatus
        };
      })
    );

    res.json({ success: true, clients: enrichedClients });
  } catch (error) {
    console.error('Error fetching clients:', error);
    res.status(500).json({ error: 'Failed to fetch SaaS clients' });
  }
};

/**
 * Toggle SaaS Kill-Switch: Block or Unblock a client Admin
 */
const toggleAdminBlockStatus = async (req, res) => {
  const { adminId, isBlocked, reason } = req.body;
  const developerId = req.user.id;

  try {
    if (!adminId || typeof isBlocked !== 'boolean') {
      return res.status(400).json({ error: 'Validation Error', message: 'adminId and isBlocked (boolean) are required.' });
    }

    const targetAdmin = await prisma.user.findUnique({
      where: { id: adminId }
    });

    if (!targetAdmin || targetAdmin.role !== 'ADMIN') {
      return res.status(404).json({ error: 'Not Found', message: 'Target client admin not found.' });
    }

    const updatedAdmin = await prisma.user.update({
      where: { id: adminId },
      data: { isBlocked }
    });

    // Record Action in SystemAuditLog
    const actionName = isBlocked ? 'BLOCK_ADMIN' : 'UNBLOCK_ADMIN';
    const detailMsg = isBlocked
      ? `Developer ${req.user.name} (${req.user.email}) activated SaaS Kill-Switch for Admin "${targetAdmin.businessName || targetAdmin.name}" (${targetAdmin.email}). Reason: ${reason || 'Non-payment or administrative lock'}.`
      : `Developer ${req.user.name} (${req.user.email}) restored platform access for Admin "${targetAdmin.businessName || targetAdmin.name}" (${targetAdmin.email}). Reason: ${reason || 'Payment cleared or administrative unlock'}.`;

    await prisma.systemAuditLog.create({
      data: {
        developerId,
        targetAdminId: adminId,
        action: actionName,
        details: detailMsg,
        ipAddress: req.ip || req.connection.remoteAddress
      }
    });

    res.json({
      success: true,
      message: `Admin ${targetAdmin.email} has been successfully ${isBlocked ? 'BLOCKED' : 'UNBLOCKED'}.`,
      client: updatedAdmin
    });
  } catch (error) {
    console.error('Error toggling admin block status:', error);
    res.status(500).json({ error: 'Failed to update admin block status' });
  }
};

/**
 * Update Admin's SaaS Subscription (Extend days, change plan)
 */
const updateClientSubscription = async (req, res) => {
  const { adminId, daysToAdd, customEndDate, planName } = req.body;
  const developerId = req.user.id;

  try {
    const admin = await prisma.user.findUnique({ where: { id: adminId } });
    if (!admin || admin.role !== 'ADMIN') {
      return res.status(404).json({ error: 'Client admin not found' });
    }

    let newEndDate;
    if (customEndDate) {
      newEndDate = new Date(customEndDate);
    } else if (daysToAdd) {
      const currentOrNow = admin.subscriptionEndDate && new Date(admin.subscriptionEndDate) > new Date()
        ? new Date(admin.subscriptionEndDate)
        : new Date();
      currentOrNow.setDate(currentOrNow.getDate() + parseInt(daysToAdd));
      newEndDate = currentOrNow;
    } else {
      return res.status(400).json({ error: 'Please provide either daysToAdd or customEndDate' });
    }

    // Update admin subscription and automatically unblock if expired
    const updated = await prisma.user.update({
      where: { id: adminId },
      data: {
        subscriptionEndDate: newEndDate,
        subscriptionPlan: planName || admin.subscriptionPlan || 'PREMIUM_PRO',
        isBlocked: false // Unblock automatically when renewed
      }
    });

    // Record audit log
    await prisma.systemAuditLog.create({
      data: {
        developerId,
        targetAdminId: adminId,
        action: 'EXTEND_SUBSCRIPTION',
        details: `Subscription extended to ${newEndDate.toISOString().split('T')[0]} for client "${admin.businessName || admin.name}" (${admin.email}). Plan: ${planName || admin.subscriptionPlan}.`
      }
    });

    res.json({
      success: true,
      message: `Subscription updated successfully until ${newEndDate.toISOString().split('T')[0]}.`,
      client: updated
    });
  } catch (error) {
    console.error('Error updating subscription:', error);
    res.status(500).json({ error: 'Failed to update subscription' });
  }
};

/**
 * Get SaaS System Audit Logs
 */
const getSystemAuditLogs = async (req, res) => {
  try {
    const logs = await prisma.systemAuditLog.findMany({
      include: {
        developer: {
          select: { name: true, email: true }
        }
      },
      orderBy: { createdAt: 'desc' },
      take: 100
    });

    res.json({ success: true, logs });
  } catch (error) {
    console.error('Error fetching audit logs:', error);
    res.status(500).json({ error: 'Failed to fetch system audit logs' });
  }
};

/**
 * Trigger automated subscription expiry sweep on demand
 */
const triggerManualSubscriptionCheck = async (req, res) => {
  try {
    const result = await checkSubscriptionExpiryNow();
    res.json({
      success: true,
      message: `Subscription sweep completed. ${result.count} accounts auto-suspended.`,
      result
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to run subscription sweep' });
  }
};

module.exports = {
  getPlatformStats,
  getAllClients,
  toggleAdminBlockStatus,
  updateClientSubscription,
  getSystemAuditLogs,
  triggerManualSubscriptionCheck
};
