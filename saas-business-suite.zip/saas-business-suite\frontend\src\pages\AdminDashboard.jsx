import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import StatCard from '../components/StatCard';
import api from '../services/api';
import * as XLSX from 'xlsx';
import {
  Users,
  Clock,
  AlertTriangle,
  Package,
  Plus,
  FileSpreadsheet,
  Search,
  Calendar,
  Edit,
  Trash2,
  CheckCircle2,
  XCircle,
  FileText,
  DollarSign,
  TrendingUp,
  History,
  ShieldCheck,
  Building2,
  Briefcase,
  ShoppingCart,
  Percent,
  BadgeDollarSign
} from 'lucide-react';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [activeTab, setActiveTab] = useState('attendance'); // 'attendance' | 'inventory' | 'financials' | 'payroll' | 'employees' | 'leaves'
  const [loading, setLoading] = useState(true);

  // Attendance state
  const [attendanceRecords, setAttendanceRecords] = useState([]);
  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 7);
    return d.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [showOverrideModal, setShowOverrideModal] = useState(false);
  const [overrideData, setOverrideData] = useState({ checkIn: '', checkOut: '', status: 'Present', notes: '' });

  // Inventory state
  const [inventoryItems, setInventoryItems] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [lowStockFilter, setLowStockFilter] = useState(false);
  const [showAddInventoryModal, setShowAddInventoryModal] = useState(false);
  const [newInventory, setNewInventory] = useState({
    itemName: '',
    sku: '',
    category: 'Hardware',
    quantity: 10,
    minStockLevel: 5,
    costPrice: 0,
    sellingPrice: 0
  });
  const [showAuditModal, setShowAuditModal] = useState(false);
  const [auditTrails, setAuditTrails] = useState([]);
  const [selectedAuditItem, setSelectedAuditItem] = useState(null);

  // Financials & Sales state
  const [financials, setFinancials] = useState(null);
  const [showSaleModal, setShowSaleModal] = useState(false);
  const [saleForm, setSaleForm] = useState({
    inventoryId: '',
    quantity: 1,
    customSellingPrice: '',
    customerName: '',
    notes: ''
  });

  // Payroll state
  const [payrollData, setPayrollData] = useState(null);

  // Employees state
  const [employees, setEmployees] = useState([]);
  const [showAddEmpModal, setShowAddEmpModal] = useState(false);
  const [newEmp, setNewEmp] = useState({
    name: '',
    email: '',
    password: '',
    department: 'Operations',
    phone: '',
    shiftStart: '09:00',
    shiftEnd: '17:00',
    salary: 4000
  });

  // Leave Requests state
  const [leaveRequests, setLeaveRequests] = useState([]);

  // Notifications
  const [notification, setNotification] = useState(null);

  const fetchAllData = async () => {
    setLoading(true);
    try {
      const [statsRes, attRes, invRes, empRes, leavesRes, finRes, payRes] = await Promise.all([
        api.get('/admin/stats'),
        api.get(`/attendance/admin?startDate=${startDate}&endDate=${endDate}`),
        api.get('/inventory'),
        api.get('/admin/employees'),
        api.get('/admin/leaves'),
        api.get('/admin/financials'),
        api.get('/admin/payroll')
      ]);

      if (statsRes.data.success) setStats(statsRes.data.stats);
      if (attRes.data.success) setAttendanceRecords(attRes.data.records);
      if (invRes.data.success) setInventoryItems(invRes.data.items);
      if (empRes.data.success) setEmployees(empRes.data.employees);
      if (leavesRes.data.success) setLeaveRequests(leavesRes.data.leaveRequests);
      if (finRes.data.success) setFinancials(finRes.data);
      if (payRes.data.success) setPayrollData(payRes.data);
    } catch (err) {
      console.error('Error fetching admin dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, [startDate, endDate]);

  // Export Attendance to Excel (.xlsx) using SheetJS
  const exportToExcel = () => {
    if (!attendanceRecords || attendanceRecords.length === 0) {
      alert('No attendance records available for the selected date range.');
      return;
    }

    const excelData = attendanceRecords.map((r, index) => ({
      'S.No': index + 1,
      'Employee Name': r.user?.name || 'Unknown',
      'Department': r.user?.department || 'Operations',
      'Assigned Shift': `${r.user?.shiftStart || '09:00'} - ${r.user?.shiftEnd || '17:00'}`,
      'Log Date': new Date(r.date).toLocaleDateString(),
      'Check-In Time': r.checkIn ? new Date(r.checkIn).toLocaleTimeString() : 'N/A',
      'Check-Out Time': r.checkOut ? new Date(r.checkOut).toLocaleTimeString() : 'N/A',
      'Total Hours Worked': r.totalHours ? `${r.totalHours} hrs` : '0',
      'Status': r.status,
      'Adjusted By': r.overriddenBy || 'Automatic Punch',
      'Notes': r.notes || ''
    }));

    const worksheet = XLSX.utils.json_to_sheet(excelData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Attendance Report');

    const fileName = `Attendance_Report_${startDate}_to_${endDate}.xlsx`;
    XLSX.writeFile(workbook, fileName);

    setNotification({
      type: 'success',
      text: `Successfully exported ${excelData.length} records to ${fileName}`
    });
  };

  // Export Payroll to Excel (.xlsx)
  const exportPayrollToExcel = () => {
    if (!payrollData || !payrollData.payroll.length) {
      alert('No payroll data to export.');
      return;
    }

    const exportRows = payrollData.payroll.map((p, idx) => ({
      'S.No': idx + 1,
      'Employee Name': p.name,
      'Department': p.department,
      'Days Present': p.totalDaysPresent,
      'Late Occurrences': p.totalLateDays,
      'Total Hours Worked': `${p.totalHoursWorked} hrs`,
      'Attendance Rate': `${p.attendanceRate}%`,
      'Base Monthly Salary': `$${p.baseSalary}`,
      'Late Penalty Deductions': `-$${p.lateDeduction}`,
      'Net Payable Salary': `$${p.netSalary}`
    }));

    const worksheet = XLSX.utils.json_to_sheet(exportRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Payroll Summary');

    const fileName = `Payroll_${payrollData.period.monthName}_${payrollData.period.year}.xlsx`;
    XLSX.writeFile(workbook, fileName);

    setNotification({
      type: 'success',
      text: `Payroll report exported to ${fileName}`
    });
  };

  // Override Attendance Handler
  const handleOverrideSubmit = async (e) => {
    e.preventDefault();
    if (!selectedRecord) return;

    try {
      const res = await api.put(`/attendance/admin/override/${selectedRecord.id}`, overrideData);
      setNotification({ type: 'success', text: res.data.message });
      setShowOverrideModal(false);
      setSelectedRecord(null);
      fetchAllData();
    } catch (err) {
      setNotification({ type: 'error', text: err.response?.data?.message || 'Override failed' });
    }
  };

  // Delete duplicate attendance record
  const handleDeleteAttendance = async (id) => {
    if (!window.confirm('Are you sure you want to delete this attendance log?')) return;

    try {
      const res = await api.delete(`/attendance/admin/${id}`);
      setNotification({ type: 'success', text: res.data.message });
      fetchAllData();
    } catch (err) {
      setNotification({ type: 'error', text: 'Failed to delete attendance log' });
    }
  };

  // Create Inventory Item
  const handleCreateInventory = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post('/inventory', newInventory);
      setNotification({ type: 'success', text: res.data.message });
      setShowAddInventoryModal(false);
      setNewInventory({
        itemName: '',
        sku: '',
        category: 'Hardware',
        quantity: 10,
        minStockLevel: 5,
        costPrice: 0,
        sellingPrice: 0
      });
      fetchAllData();
    } catch (err) {
      setNotification({ type: 'error', text: err.response?.data?.error || 'Failed to create inventory item' });
    }
  };

  // Record Sale & Deduct Inventory
  const handleRecordSale = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post('/admin/sales', saleForm);
      setNotification({ type: 'success', text: res.data.message });
      setShowSaleModal(false);
      setSaleForm({
        inventoryId: '',
        quantity: 1,
        customSellingPrice: '',
        customerName: '',
        notes: ''
      });
      fetchAllData();
    } catch (err) {
      setNotification({ type: 'error', text: err.response?.data?.message || err.response?.data?.error || 'Failed to record sale' });
    }
  };

  // View Item Audit History
  const handleViewAudit = async (item) => {
    setSelectedAuditItem(item);
    try {
      const res = await api.get(`/inventory/audit/${item.id}`);
      if (res.data.success) {
        setAuditTrails(res.data.trails);
        setShowAuditModal(true);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Create Employee
  const handleCreateEmployee = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post('/admin/employees', newEmp);
      setNotification({ type: 'success', text: res.data.message });
      setShowAddEmpModal(false);
      setNewEmp({
        name: '',
        email: '',
        password: '',
        department: 'Operations',
        phone: '',
        shiftStart: '09:00',
        shiftEnd: '17:00',
        salary: 4000
      });
      fetchAllData();
    } catch (err) {
      setNotification({ type: 'error', text: err.response?.data?.error || 'Failed to create employee' });
    }
  };

  // Approve / Reject Leave
  const handleReviewLeave = async (id, status) => {
    try {
      const res = await api.put(`/admin/leaves/${id}/status`, { status });
      setNotification({ type: 'success', text: res.data.message });
      fetchAllData();
    } catch (err) {
      setNotification({ type: 'error', text: 'Failed to update leave request' });
    }
  };

  // Filtered inventory based on live search & filter
  const filteredInventory = inventoryItems.filter(item => {
    const matchesSearch = item.itemName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'All' || item.category === categoryFilter;
    const matchesLowStock = !lowStockFilter || item.quantity <= item.minStockLevel;

    return matchesSearch && matchesCategory && matchesLowStock;
  });

  const selectedSaleItem = inventoryItems.find(i => i.id === saleForm.inventoryId);
  const estimatedRevenue = selectedSaleItem ? (parseFloat(saleForm.customSellingPrice || selectedSaleItem.sellingPrice) * (parseInt(saleForm.quantity) || 0)) : 0;
  const estimatedCost = selectedSaleItem ? (selectedSaleItem.costPrice * (parseInt(saleForm.quantity) || 0)) : 0;
  const estimatedProfit = estimatedRevenue - estimatedCost;

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans">
      <Navbar />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Top Header Banner */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-800/90 p-6 rounded-2xl border border-slate-700 shadow-xl">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">Client Business Management</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1 tracking-tight">
              Corporate Operations & Profit Center
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Live tracking for workforce attendance, inventory stock levels, profit & loss, payroll disbursements, and leave approvals.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setShowSaleModal(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition shadow-lg shadow-purple-600/20 active:scale-[0.98]"
            >
              <ShoppingCart className="w-4 h-4" /> Record New Sale
            </button>
            <button
              onClick={exportToExcel}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition shadow-lg shadow-emerald-600/20 active:scale-[0.98]"
            >
              <FileSpreadsheet className="w-4 h-4" /> Export Attendance (.xlsx)
            </button>
            <button
              onClick={() => setShowAddEmpModal(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition shadow-lg shadow-blue-600/20 active:scale-[0.98]"
            >
              <Plus className="w-4 h-4" /> Add Employee
            </button>
            <button
              onClick={() => setShowAddInventoryModal(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-bold transition active:scale-[0.98]"
            >
              <Package className="w-4 h-4" /> Add Stock Item
            </button>
          </div>
        </div>

        {/* Notification Alert */}
        {notification && (
          <div className={`p-4 rounded-xl flex items-center justify-between text-sm ${
            notification.type === 'success'
              ? 'bg-emerald-950/70 border border-emerald-500/40 text-emerald-200'
              : 'bg-rose-950/70 border border-rose-500/40 text-rose-200'
          }`}>
            <div className="flex items-center gap-2 font-medium">
              {notification.type === 'success' ? <CheckCircle2 className="w-5 h-5 text-emerald-400" /> : <AlertTriangle className="w-5 h-5 text-rose-400" />}
              {notification.text}
            </div>
            <button onClick={() => setNotification(null)} className="text-xs opacity-75 hover:opacity-100">Dismiss</button>
          </div>
        )}

        {/* 1. VISUAL WIDGETS & REAL-TIME STATS */}
        {stats && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              title="Present Today"
              value={stats.presentToday}
              subtext={`${stats.absentToday} absent of ${stats.totalEmployees} total staff`}
              icon={Users}
              color="emerald"
            />
            <StatCard
              title="Late Comers"
              value={stats.lateComers}
              subtext="Arrived past shift start time"
              icon={Clock}
              color="amber"
              alert={stats.lateComers > 0}
            />
            <StatCard
              title="Low Stock Alerts"
              value={stats.lowStockCount}
              subtext="Catalog items below min threshold"
              icon={AlertTriangle}
              color="amber"
              alert={stats.lowStockCount > 0}
            />
            <StatCard
              title="Gross Profit Generated"
              value={financials ? `$${financials.summary.grossProfit.toLocaleString()}` : `$0`}
              subtext={financials ? `${financials.summary.profitMargin}% margin on $${financials.summary.totalRevenue.toLocaleString()} sales` : 'Sales revenue'}
              icon={TrendingUp}
              color="purple"
            />
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="bg-slate-800/80 rounded-2xl border border-slate-700/80 shadow-xl overflow-hidden">
          <div className="flex flex-wrap border-b border-slate-700/80 px-6 pt-3 gap-2 sm:gap-6">
            <button
              onClick={() => setActiveTab('attendance')}
              className={`pb-4 text-sm font-bold flex items-center gap-2 transition border-b-2 ${
                activeTab === 'attendance'
                  ? 'border-emerald-400 text-emerald-300'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Clock className="w-4 h-4" /> Attendance & Shifts
            </button>
            <button
              onClick={() => setActiveTab('inventory')}
              className={`pb-4 text-sm font-bold flex items-center gap-2 transition border-b-2 ${
                activeTab === 'inventory'
                  ? 'border-emerald-400 text-emerald-300'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Package className="w-4 h-4" /> Inventory & Stock
              {stats?.lowStockCount > 0 && (
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  {stats.lowStockCount} low
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('financials')}
              className={`pb-4 text-sm font-bold flex items-center gap-2 transition border-b-2 ${
                activeTab === 'financials'
                  ? 'border-emerald-400 text-emerald-300'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <TrendingUp className="w-4 h-4" /> Profit & Loss / Sales
            </button>
            <button
              onClick={() => setActiveTab('payroll')}
              className={`pb-4 text-sm font-bold flex items-center gap-2 transition border-b-2 ${
                activeTab === 'payroll'
                  ? 'border-emerald-400 text-emerald-300'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <BadgeDollarSign className="w-4 h-4" /> Payroll & Performance
            </button>
            <button
              onClick={() => setActiveTab('employees')}
              className={`pb-4 text-sm font-bold flex items-center gap-2 transition border-b-2 ${
                activeTab === 'employees'
                  ? 'border-emerald-400 text-emerald-300'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Users className="w-4 h-4" /> Team Directory ({employees.length})
            </button>
            <button
              onClick={() => setActiveTab('leaves')}
              className={`pb-4 text-sm font-bold flex items-center gap-2 transition border-b-2 ${
                activeTab === 'leaves'
                  ? 'border-emerald-400 text-emerald-300'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileText className="w-4 h-4" /> Leaves ({leaveRequests.length})
            </button>
          </div>

          {/* TAB 1: ATTENDANCE MANAGEMENT */}
          {activeTab === 'attendance' && (
            <div className="p-6 space-y-5">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-xl border border-slate-700">
                <div className="flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-emerald-400 shrink-0" />
                  <div>
                    <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">Date Range Filter:</span>
                    <div className="flex items-center gap-2 mt-1">
                      <input
                        type="date"
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                        className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white"
                      />
                      <span className="text-xs text-slate-400">to</span>
                      <input
                        type="date"
                        value={endDate}
                        onChange={(e) => setEndDate(e.target.value)}
                        className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={exportToExcel}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600/30 text-emerald-300 hover:bg-emerald-600/50 border border-emerald-500/40 text-xs font-semibold transition"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-400" /> Export Range (.xlsx)
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-700">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-900/90 uppercase tracking-wider text-[11px] text-slate-400 border-b border-slate-700">
                    <tr>
                      <th className="py-3 px-4">Employee</th>
                      <th className="py-3 px-4">Date</th>
                      <th className="py-3 px-4">Shift</th>
                      <th className="py-3 px-4">Check-In</th>
                      <th className="py-3 px-4">Check-Out</th>
                      <th className="py-3 px-4">Hours</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Notes / Override</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/60">
                    {attendanceRecords.length === 0 ? (
                      <tr>
                        <td colSpan="9" className="py-8 text-center text-slate-500">
                          No attendance records found for the selected date range.
                        </td>
                      </tr>
                    ) : (
                      attendanceRecords.map((rec) => (
                        <tr key={rec.id} className="hover:bg-slate-700/30 transition">
                          <td className="py-3.5 px-4 font-bold text-white">
                            {rec.user?.name || 'Employee'}
                            <div className="text-[11px] font-normal text-slate-400">{rec.user?.department || 'Operations'}</div>
                          </td>
                          <td className="py-3.5 px-4 text-slate-300">
                            {new Date(rec.date).toLocaleDateString()}
                          </td>
                          <td className="py-3.5 px-4 text-slate-400">
                            {rec.user?.shiftStart || '09:00'} - {rec.user?.shiftEnd || '17:00'}
                          </td>
                          <td className="py-3.5 px-4 font-mono font-medium text-slate-200">
                            {rec.checkIn ? new Date(rec.checkIn).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-'}
                          </td>
                          <td className="py-3.5 px-4 font-mono font-medium text-slate-200">
                            {rec.checkOut ? new Date(rec.checkOut).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-'}
                          </td>
                          <td className="py-3.5 px-4 font-bold text-slate-200">
                            {rec.totalHours ? `${rec.totalHours} hrs` : '-'}
                          </td>
                          <td className="py-3.5 px-4">
                            <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
                              rec.status === 'Present'
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                : rec.status === 'Late'
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                                : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                            }`}>
                              {rec.status}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-slate-400 text-[11px]">
                            {rec.overriddenBy ? (
                              <span className="text-purple-300 font-medium">Adjusted by {rec.overriddenBy}</span>
                            ) : (
                              rec.notes || 'Normal'
                            )}
                          </td>
                          <td className="py-3.5 px-4 text-right space-x-1.5 whitespace-nowrap">
                            <button
                              onClick={() => {
                                setSelectedRecord(rec);
                                setOverrideData({
                                  checkIn: rec.checkIn ? new Date(rec.checkIn).toISOString().slice(0, 16) : '',
                                  checkOut: rec.checkOut ? new Date(rec.checkOut).toISOString().slice(0, 16) : '',
                                  status: rec.status,
                                  notes: rec.notes || ''
                                });
                                setShowOverrideModal(true);
                              }}
                              title="Manual Override"
                              className="p-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 transition"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteAttendance(rec.id)}
                              title="Delete Record"
                              className="p-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 border border-rose-800/40 transition"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 2: INVENTORY & STOCK */}
          {activeTab === 'inventory' && (
            <div className="p-6 space-y-5">
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Live search by Item Name, SKU, or Category..."
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-400 focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setLowStockFilter(!lowStockFilter)}
                    className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border ${
                      lowStockFilter
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                        : 'bg-slate-900 text-slate-400 border-slate-700 hover:text-white'
                    }`}
                  >
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>Low Stock Only</span>
                  </button>

                  <button
                    onClick={() => setShowAddInventoryModal(true)}
                    className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white flex items-center gap-1.5 shadow-lg shadow-emerald-600/20"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add Stock Item
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-700">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-900/90 uppercase tracking-wider text-[11px] text-slate-400 border-b border-slate-700">
                    <tr>
                      <th className="py-3 px-4">Item Name</th>
                      <th className="py-3 px-4">SKU</th>
                      <th className="py-3 px-4">Category</th>
                      <th className="py-3 px-4">Stock Quantity</th>
                      <th className="py-3 px-4">Unit Pricing</th>
                      <th className="py-3 px-4">Last Updated By</th>
                      <th className="py-3 px-4 text-right">Audit & Controls</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/60">
                    {filteredInventory.length === 0 ? (
                      <tr>
                        <td colSpan="7" className="py-8 text-center text-slate-500">
                          No items match your search filter.
                        </td>
                      </tr>
                    ) : (
                      filteredInventory.map((item) => {
                        const isLowStock = item.quantity <= item.minStockLevel;
                        return (
                          <tr key={item.id} className="hover:bg-slate-700/30 transition">
                            <td className="py-3.5 px-4 font-bold text-white text-sm">
                              {item.itemName}
                              {isLowStock && (
                                <span className="ml-2 inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                                  <AlertTriangle className="w-2.5 h-2.5" /> Low Stock
                                </span>
                              )}
                            </td>
                            <td className="py-3.5 px-4 font-mono text-slate-300 font-semibold">
                              {item.sku}
                            </td>
                            <td className="py-3.5 px-4 text-slate-400">
                              {item.category}
                            </td>
                            <td className="py-3.5 px-4">
                              <span className={`font-bold text-sm ${isLowStock ? 'text-amber-400' : 'text-emerald-400'}`}>
                                {item.quantity} units
                              </span>
                              <span className="text-[10px] text-slate-400 block">Min: {item.minStockLevel}</span>
                            </td>
                            <td className="py-3.5 px-4 text-slate-300">
                              <div>Cost: <span className="font-semibold text-slate-200">${item.costPrice}</span></div>
                              <div>Selling: <span className="font-semibold text-emerald-400">${item.sellingPrice}</span></div>
                            </td>
                            <td className="py-3.5 px-4 text-slate-400">
                              <div className="font-medium text-slate-300">{item.lastUpdatedBy}</div>
                              <div className="text-[10px]">{new Date(item.updatedAt).toLocaleString()}</div>
                            </td>
                            <td className="py-3.5 px-4 text-right space-x-1.5 whitespace-nowrap">
                              <button
                                onClick={() => handleViewAudit(item)}
                                className="px-2.5 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-semibold transition inline-flex items-center gap-1"
                              >
                                <History className="w-3.5 h-3.5 text-blue-400" /> Audit Log
                              </button>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: PROFIT & LOSS / SALES FINANCIALS */}
          {activeTab === 'financials' && (
            <div className="p-6 space-y-6">
              {/* Financial KPI Cards */}
              {financials && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-700">
                    <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">Gross Sales Revenue</span>
                    <div className="text-2xl font-black text-white mt-1">${financials.summary.totalRevenue.toLocaleString()}</div>
                    <span className="text-[11px] text-slate-400">{financials.summary.totalSalesCount} completed orders</span>
                  </div>
                  <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-700">
                    <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">Cost of Goods Sold (COGS)</span>
                    <div className="text-2xl font-black text-slate-300 mt-1">${financials.summary.totalCost.toLocaleString()}</div>
                    <span className="text-[11px] text-slate-400">Direct inventory acquisition cost</span>
                  </div>
                  <div className="p-4 rounded-xl bg-slate-900/90 border border-emerald-500/30">
                    <span className="text-xs text-emerald-400 font-medium uppercase tracking-wider">Net Gross Profit</span>
                    <div className="text-2xl font-black text-emerald-400 mt-1">${financials.summary.grossProfit.toLocaleString()}</div>
                    <span className="text-[11px] text-emerald-300/80">Revenue minus product costs</span>
                  </div>
                  <div className="p-4 rounded-xl bg-slate-900/90 border border-purple-500/30">
                    <span className="text-xs text-purple-400 font-medium uppercase tracking-wider">Profit Margin Ratio</span>
                    <div className="text-2xl font-black text-purple-400 mt-1">{financials.summary.profitMargin}%</div>
                    <span className="text-[11px] text-purple-300/80">Return on gross sales</span>
                  </div>
                </div>
              )}

              {/* Sales Log Table */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider">Completed Sales Transactions</h3>
                  <button
                    onClick={() => setShowSaleModal(true)}
                    className="px-3.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" /> Dispatch / Sell Item
                  </button>
                </div>

                <div className="overflow-x-auto rounded-xl border border-slate-700">
                  <table className="w-full text-left text-xs text-slate-300">
                    <thead className="bg-slate-900/90 uppercase tracking-wider text-[11px] text-slate-400 border-b border-slate-700">
                      <tr>
                        <th className="py-3 px-4">Transaction Date</th>
                        <th className="py-3 px-4">Item Dispatched</th>
                        <th className="py-3 px-4">Customer</th>
                        <th className="py-3 px-4">Quantity</th>
                        <th className="py-3 px-4">Sale Price</th>
                        <th className="py-3 px-4">Total Revenue</th>
                        <th className="py-3 px-4">Net Profit</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-700/60">
                      {!financials || financials.recentTransactions.length === 0 ? (
                        <tr>
                          <td colSpan="7" className="py-8 text-center text-slate-500">
                            No sales transactions recorded yet. Click "Record New Sale" to dispatch inventory.
                          </td>
                        </tr>
                      ) : (
                        financials.recentTransactions.map((tx) => (
                          <tr key={tx.id} className="hover:bg-slate-700/30 transition">
                            <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                              {new Date(tx.createdAt).toLocaleString()}
                            </td>
                            <td className="py-3 px-4 font-bold text-white">
                              {tx.itemName}
                            </td>
                            <td className="py-3 px-4 text-slate-300">
                              {tx.customerName || 'Walk-in'}
                            </td>
                            <td className="py-3 px-4 font-bold text-slate-200">
                              {tx.quantity} units
                            </td>
                            <td className="py-3 px-4 text-slate-300">
                              ${tx.sellingPrice}
                            </td>
                            <td className="py-3 px-4 font-bold text-white">
                              ${tx.totalRevenue}
                            </td>
                            <td className="py-3 px-4 font-bold text-emerald-400">
                              +${tx.totalProfit}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: PAYROLL & PERFORMANCE */}
          {activeTab === 'payroll' && (
            <div className="p-6 space-y-6">
              {payrollData && (
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-xl border border-slate-700">
                  <div>
                    <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">Payroll Period</span>
                    <h3 className="text-lg font-bold text-white">
                      {payrollData.period.monthName} {payrollData.period.year}
                    </h3>
                    <p className="text-xs text-slate-400">
                      Total Disbursable: <span className="font-bold text-emerald-400">${payrollData.summary.totalPayrollDisbursement.toLocaleString()}</span> across {payrollData.summary.totalStaffCount} staff
                    </p>
                  </div>

                  <button
                    onClick={exportPayrollToExcel}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition shadow-lg shadow-emerald-600/20"
                  >
                    <FileSpreadsheet className="w-4 h-4" /> Export Payroll Sheet (.xlsx)
                  </button>
                </div>
              )}

              {/* Payroll Table */}
              <div className="overflow-x-auto rounded-xl border border-slate-700">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-900/90 uppercase tracking-wider text-[11px] text-slate-400 border-b border-slate-700">
                    <tr>
                      <th className="py-3 px-4">Staff Member</th>
                      <th className="py-3 px-4">Department</th>
                      <th className="py-3 px-4">Days Present</th>
                      <th className="py-3 px-4">Late Arrivals</th>
                      <th className="py-3 px-4">Hours Worked</th>
                      <th className="py-3 px-4">Attendance Rate</th>
                      <th className="py-3 px-4">Base Salary</th>
                      <th className="py-3 px-4">Late Deductions</th>
                      <th className="py-3 px-4">Net Payout</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/60">
                    {!payrollData || payrollData.payroll.length === 0 ? (
                      <tr>
                        <td colSpan="9" className="py-8 text-center text-slate-500">
                          No staff payroll records generated.
                        </td>
                      </tr>
                    ) : (
                      payrollData.payroll.map((p) => (
                        <tr key={p.employeeId} className="hover:bg-slate-700/30 transition">
                          <td className="py-3.5 px-4 font-bold text-white">
                            {p.name}
                            <span className="block text-[11px] font-normal text-slate-400">{p.email}</span>
                          </td>
                          <td className="py-3.5 px-4 font-medium text-slate-300">
                            {p.department}
                          </td>
                          <td className="py-3.5 px-4 text-slate-200">
                            {p.totalDaysPresent} days
                          </td>
                          <td className="py-3.5 px-4">
                            <span className={`font-semibold ${p.totalLateDays > 2 ? 'text-amber-400' : 'text-slate-300'}`}>
                              {p.totalLateDays} late
                            </span>
                            {p.excessiveLateDays > 0 && (
                              <span className="text-[10px] text-rose-400 block font-bold">(-${p.lateDeduction})</span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 font-bold text-slate-200">
                            {p.totalHoursWorked} hrs
                          </td>
                          <td className="py-3.5 px-4">
                            <div className="flex items-center gap-2">
                              <div className="w-16 h-2 bg-slate-700 rounded-full overflow-hidden">
                                <div
                                  className={`h-full ${p.attendanceRate >= 80 ? 'bg-emerald-500' : 'bg-amber-500'}`}
                                  style={{ width: `${Math.min(100, p.attendanceRate)}%` }}
                                ></div>
                              </div>
                              <span className="text-[11px] font-bold">{p.attendanceRate}%</span>
                            </div>
                          </td>
                          <td className="py-3.5 px-4 font-semibold text-slate-300">
                            ${p.baseSalary.toLocaleString()}
                          </td>
                          <td className="py-3.5 px-4 text-rose-400 font-bold">
                            {p.lateDeduction > 0 ? `-$${p.lateDeduction}` : '$0'}
                          </td>
                          <td className="py-3.5 px-4 font-black text-emerald-400 text-sm">
                            ${p.netSalary.toLocaleString()}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 5: TEAM DIRECTORY */}
          {activeTab === 'employees' && (
            <div className="p-6 space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-white">Workforce Directory & Shifts</h3>
                  <p className="text-xs text-slate-400">Manage team profiles, assigned shift schedules, and operational departments.</p>
                </div>
                <button
                  onClick={() => setShowAddEmpModal(true)}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white flex items-center gap-1.5 shadow-lg shadow-blue-600/20"
                >
                  <Plus className="w-3.5 h-3.5" /> Add Staff Member
                </button>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-700">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-900/90 uppercase tracking-wider text-[11px] text-slate-400 border-b border-slate-700">
                    <tr>
                      <th className="py-3 px-4">Staff Name</th>
                      <th className="py-3 px-4">Email Address</th>
                      <th className="py-3 px-4">Department</th>
                      <th className="py-3 px-4">Assigned Shift</th>
                      <th className="py-3 px-4">Salary</th>
                      <th className="py-3 px-4">Contact</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/60">
                    {employees.map((emp) => (
                      <tr key={emp.id} className="hover:bg-slate-700/30 transition">
                        <td className="py-3.5 px-4 font-bold text-white text-sm">
                          {emp.name}
                        </td>
                        <td className="py-3.5 px-4 text-slate-300 font-mono">
                          {emp.email}
                        </td>
                        <td className="py-3.5 px-4 font-medium text-slate-200">
                          {emp.department}
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-blue-950/60 text-blue-300 border border-blue-800">
                            {emp.shiftStart} - {emp.shiftEnd}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 font-semibold text-emerald-400">
                          ${emp.salary?.toLocaleString() || '0'}
                        </td>
                        <td className="py-3.5 px-4 text-slate-400">
                          {emp.phone || 'N/A'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 6: LEAVE INQUIRIES */}
          {activeTab === 'leaves' && (
            <div className="p-6 space-y-5">
              <div>
                <h3 className="text-base font-bold text-white">Employee Leave Inquiries</h3>
                <p className="text-xs text-slate-400">Review time-off submissions and mark approvals or rejections.</p>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-700">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-900/90 uppercase tracking-wider text-[11px] text-slate-400 border-b border-slate-700">
                    <tr>
                      <th className="py-3 px-4">Employee</th>
                      <th className="py-3 px-4">Reason</th>
                      <th className="py-3 px-4">Duration Range</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Review Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/60">
                    {leaveRequests.length === 0 ? (
                      <tr>
                        <td colSpan="5" className="py-8 text-center text-slate-500">
                          No leave applications pending review.
                        </td>
                      </tr>
                    ) : (
                      leaveRequests.map((lr) => (
                        <tr key={lr.id} className="hover:bg-slate-700/30 transition">
                          <td className="py-3.5 px-4 font-bold text-white">
                            {lr.user?.name}
                            <span className="block text-[11px] font-normal text-slate-400">{lr.user?.department}</span>
                          </td>
                          <td className="py-3.5 px-4 text-slate-200">
                            {lr.reason}
                          </td>
                          <td className="py-3.5 px-4 text-slate-400 whitespace-nowrap">
                            {new Date(lr.startDate).toLocaleDateString()} - {new Date(lr.endDate).toLocaleDateString()}
                          </td>
                          <td className="py-3.5 px-4">
                            <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
                              lr.status === 'Approved'
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                : lr.status === 'Rejected'
                                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                                : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                            }`}>
                              {lr.status}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-right space-x-2 whitespace-nowrap">
                            {lr.status === 'Pending' ? (
                              <>
                                <button
                                  onClick={() => handleReviewLeave(lr.id, 'Approved')}
                                  className="px-3 py-1 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white inline-flex items-center gap-1 shadow-sm"
                                >
                                  <CheckCircle2 className="w-3.5 h-3.5" /> Approve
                                </button>
                                <button
                                  onClick={() => handleReviewLeave(lr.id, 'Rejected')}
                                  className="px-3 py-1 rounded-lg text-xs font-bold bg-rose-600/80 hover:bg-rose-600 text-white inline-flex items-center gap-1 shadow-sm"
                                >
                                  <XCircle className="w-3.5 h-3.5" /> Reject
                                </button>
                              </>
                            ) : (
                              <span className="text-xs text-slate-400">Reviewed by {lr.reviewedBy || 'Admin'}</span>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* MODAL 1: RECORD NEW SALE */}
        {showSaleModal && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-slate-800 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl">
              <h3 className="text-lg font-bold text-white mb-1">Record New Inventory Sale</h3>
              <p className="text-xs text-slate-400 mb-4">Stock will be automatically deducted, revenue computed, and audit logged.</p>

              <form onSubmit={handleRecordSale} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Select Item</label>
                  <select
                    required
                    value={saleForm.inventoryId}
                    onChange={(e) => setSaleForm({ ...saleForm, inventoryId: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                  >
                    <option value="">-- Choose Stock Item --</option>
                    {inventoryItems.map((item) => (
                      <option key={item.id} value={item.id} disabled={item.quantity <= 0}>
                        {item.itemName} (Stock: {item.quantity} | Cost: ${item.costPrice} | Retail: ${item.sellingPrice})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Quantity</label>
                    <input
                      type="number"
                      min="1"
                      max={selectedSaleItem?.quantity || 999}
                      required
                      value={saleForm.quantity}
                      onChange={(e) => setSaleForm({ ...saleForm, quantity: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Custom Unit Price ($)</label>
                    <input
                      type="number"
                      step="0.01"
                      placeholder={selectedSaleItem ? `$${selectedSaleItem.sellingPrice}` : '$0'}
                      value={saleForm.customSellingPrice}
                      onChange={(e) => setSaleForm({ ...saleForm, customSellingPrice: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                    />
                  </div>
                </div>

                {selectedSaleItem && (
                  <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-700 text-xs flex items-center justify-between">
                    <div>
                      <span className="text-slate-400">Total Revenue:</span>
                      <div className="font-bold text-white text-sm">${estimatedRevenue.toFixed(2)}</div>
                    </div>
                    <div>
                      <span className="text-slate-400">Est. Gross Profit:</span>
                      <div className="font-bold text-emerald-400 text-sm">+${estimatedProfit.toFixed(2)}</div>
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Customer / Client Name</label>
                  <input
                    type="text"
                    placeholder="e.g. Apex Outbound Fleet"
                    value={saleForm.customerName}
                    onChange={(e) => setSaleForm({ ...saleForm, customerName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-3">
                  <button
                    type="button"
                    onClick={() => setShowSaleModal(false)}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl text-xs font-bold bg-purple-600 hover:bg-purple-500 text-white shadow-lg shadow-purple-600/20"
                  >
                    Confirm & Record Sale
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* MODAL 2: OVERRIDE ATTENDANCE */}
        {showOverrideModal && selectedRecord && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-slate-800 border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl">
              <h3 className="text-lg font-bold text-white mb-1">Manual Attendance Adjustment</h3>
              <p className="text-xs text-slate-400 mb-4">
                Employee: <span className="font-semibold text-slate-200">{selectedRecord.user?.name}</span> ({new Date(selectedRecord.date).toLocaleDateString()})
              </p>

              <form onSubmit={handleOverrideSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Check-In Timestamp
                  </label>
                  <input
                    type="datetime-local"
                    value={overrideData.checkIn}
                    onChange={(e) => setOverrideData({ ...overrideData, checkIn: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Check-Out Timestamp
                  </label>
                  <input
                    type="datetime-local"
                    value={overrideData.checkOut}
                    onChange={(e) => setOverrideData({ ...overrideData, checkOut: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Attendance Status
                  </label>
                  <select
                    value={overrideData.status}
                    onChange={(e) => setOverrideData({ ...overrideData, status: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                  >
                    <option value="Present">Present</option>
                    <option value="Late">Late</option>
                    <option value="Half-Day">Half-Day</option>
                    <option value="Absent">Absent</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Override Reason / Notes
                  </label>
                  <input
                    type="text"
                    value={overrideData.notes}
                    onChange={(e) => setOverrideData({ ...overrideData, notes: e.target.value })}
                    placeholder="e.g. Employee forgot to punch out due to offsite client delivery"
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-3">
                  <button
                    type="button"
                    onClick={() => setShowOverrideModal(false)}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/20"
                  >
                    Save Override
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* MODAL 3: ADD INVENTORY ITEM */}
        {showAddInventoryModal && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-slate-800 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl">
              <h3 className="text-lg font-bold text-white mb-4">Add New Inventory Stock</h3>
              <form onSubmit={handleCreateInventory} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Item Name</label>
                  <input
                    type="text"
                    required
                    value={newInventory.itemName}
                    onChange={(e) => setNewInventory({ ...newInventory, itemName: e.target.value })}
                    placeholder="e.g. Wireless Thermal Receipt Printer"
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">SKU Code</label>
                    <input
                      type="text"
                      required
                      value={newInventory.sku}
                      onChange={(e) => setNewInventory({ ...newInventory, sku: e.target.value })}
                      placeholder="e.g. SKU-PRN-901"
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Category</label>
                    <input
                      type="text"
                      value={newInventory.category}
                      onChange={(e) => setNewInventory({ ...newInventory, category: e.target.value })}
                      placeholder="e.g. Hardware, Packaging"
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Initial Quantity</label>
                    <input
                      type="number"
                      required
                      value={newInventory.quantity}
                      onChange={(e) => setNewInventory({ ...newInventory, quantity: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Min Alert Level</label>
                    <input
                      type="number"
                      required
                      value={newInventory.minStockLevel}
                      onChange={(e) => setNewInventory({ ...newInventory, minStockLevel: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Cost Price ($)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={newInventory.costPrice}
                      onChange={(e) => setNewInventory({ ...newInventory, costPrice: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Selling Price ($)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={newInventory.sellingPrice}
                      onChange={(e) => setNewInventory({ ...newInventory, sellingPrice: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-end gap-3 pt-3">
                  <button
                    type="button"
                    onClick={() => setShowAddInventoryModal(false)}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/20"
                  >
                    Create Stock Item
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* MODAL 4: INVENTORY AUDIT TRAIL */}
        {showAuditModal && selectedAuditItem && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-slate-800 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-bold text-white">Item Modification Audit Trail</h3>
                  <p className="text-xs text-slate-400">{selectedAuditItem.itemName} ({selectedAuditItem.sku})</p>
                </div>
                <button onClick={() => setShowAuditModal(false)} className="text-slate-400 hover:text-white text-xs font-bold">Close</button>
              </div>

              <div className="max-h-80 overflow-y-auto space-y-3 pr-2">
                {auditTrails.length === 0 ? (
                  <p className="text-xs text-slate-500">No modification trail recorded yet for this item.</p>
                ) : (
                  auditTrails.map((trail) => (
                    <div key={trail.id} className="p-3 rounded-xl bg-slate-900 border border-slate-700/70 text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          trail.action === 'CREATED' ? 'bg-emerald-950 text-emerald-300' : 'bg-blue-950 text-blue-300'
                        }`}>
                          {trail.action}
                        </span>
                        <span className="text-[10px] text-slate-400">{new Date(trail.createdAt).toLocaleString()}</span>
                      </div>
                      <p className="text-slate-200">{trail.details}</p>
                      <p className="text-[10px] text-slate-400">By user: <span className="text-slate-300 font-semibold">{trail.user?.name}</span></p>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* MODAL 5: ADD EMPLOYEE */}
        {showAddEmpModal && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-slate-800 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl">
              <h3 className="text-lg font-bold text-white mb-4">Register New Staff Member</h3>
              <form onSubmit={handleCreateEmployee} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={newEmp.name}
                    onChange={(e) => setNewEmp({ ...newEmp, name: e.target.value })}
                    placeholder="e.g. Jason Bourne"
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Email</label>
                    <input
                      type="email"
                      required
                      value={newEmp.email}
                      onChange={(e) => setNewEmp({ ...newEmp, email: e.target.value })}
                      placeholder="jason@company.com"
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Initial Password</label>
                    <input
                      type="password"
                      required
                      value={newEmp.password}
                      onChange={(e) => setNewEmp({ ...newEmp, password: e.target.value })}
                      placeholder="••••••••"
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Department</label>
                    <input
                      type="text"
                      value={newEmp.department}
                      onChange={(e) => setNewEmp({ ...newEmp, department: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Phone</label>
                    <input
                      type="text"
                      value={newEmp.phone}
                      onChange={(e) => setNewEmp({ ...newEmp, phone: e.target.value })}
                      placeholder="+1 (555) 000-0000"
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Shift Start Time</label>
                    <input
                      type="time"
                      value={newEmp.shiftStart}
                      onChange={(e) => setNewEmp({ ...newEmp, shiftStart: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Shift End Time</label>
                    <input
                      type="time"
                      value={newEmp.shiftEnd}
                      onChange={(e) => setNewEmp({ ...newEmp, shiftEnd: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Monthly Salary ($)</label>
                  <input
                    type="number"
                    value={newEmp.salary}
                    onChange={(e) => setNewEmp({ ...newEmp, salary: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-3">
                  <button
                    type="button"
                    onClick={() => setShowAddEmpModal(false)}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-600/20"
                  >
                    Add Employee
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
