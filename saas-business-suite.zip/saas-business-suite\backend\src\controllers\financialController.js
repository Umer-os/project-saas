const prisma = require('../config/prisma');

/**
 * Get Profit & Loss and Sales Financial Metrics for Business Owner
 */
const getFinancialAnalytics = async (req, res) => {
  const adminId = req.user.id;

  try {
    const transactions = await prisma.saleTransaction.findMany({
      where: { adminId },
      orderBy: { createdAt: 'desc' }
    });

    const totalRevenue = transactions.reduce((acc, curr) => acc + curr.totalRevenue, 0);
    const totalCost = transactions.reduce((acc, curr) => acc + (curr.costPrice * curr.quantity), 0);
    const grossProfit = totalRevenue - totalCost;
    const profitMargin = totalRevenue > 0 ? parseFloat(((grossProfit / totalRevenue) * 100).toFixed(1)) : 0;

    // Monthly breakdown (last 6 months)
    const monthlySales = {};
    transactions.forEach(t => {
      const monthKey = new Date(t.createdAt).toLocaleString('default', { month: 'short', year: 'numeric' });
      if (!monthlySales[monthKey]) {
        monthlySales[monthKey] = { month: monthKey, revenue: 0, profit: 0, orders: 0 };
      }
      monthlySales[monthKey].revenue += t.totalRevenue;
      monthlySales[monthKey].profit += t.totalProfit;
      monthlySales[monthKey].orders += 1;
    });

    res.json({
      success: true,
      summary: {
        totalRevenue: parseFloat(totalRevenue.toFixed(2)),
        totalCost: parseFloat(totalCost.toFixed(2)),
        grossProfit: parseFloat(grossProfit.toFixed(2)),
        profitMargin,
        totalSalesCount: transactions.length,
        monthlyTrend: Object.values(monthlySales)
      },
      recentTransactions: transactions.slice(0, 20)
    });
  } catch (error) {
    console.error('Financial analytics error:', error);
    res.status(500).json({ error: 'Failed to retrieve financial metrics' });
  }
};

/**
 * Record a New Item Sale & Update Stock Automatically
 */
const recordSale = async (req, res) => {
  const adminId = req.user.id;
  const { inventoryId, quantity, customSellingPrice, customerName, notes } = req.body;

  try {
    const qty = parseInt(quantity);
    if (!inventoryId || isNaN(qty) || qty <= 0) {
      return res.status(400).json({ error: 'Valid inventory item and quantity (>0) are required' });
    }

    const item = await prisma.inventory.findFirst({
      where: { id: inventoryId, adminId }
    });

    if (!item) {
      return res.status(404).json({ error: 'Inventory item not found' });
    }

    if (item.quantity < qty) {
      return res.status(400).json({
        error: 'Insufficient Stock',
        message: `Only ${item.quantity} units of "${item.itemName}" are in stock. Cannot sell ${qty} units.`
      });
    }

    const sellingPrice = customSellingPrice !== undefined && customSellingPrice !== ''
      ? parseFloat(customSellingPrice)
      : item.sellingPrice;
    const costPrice = item.costPrice;
    const totalRevenue = parseFloat((sellingPrice * qty).toFixed(2));
    const totalProfit = parseFloat(((sellingPrice - costPrice) * qty).toFixed(2));

    // 1. Deduct Inventory Stock
    const remainingQty = item.quantity - qty;
    await prisma.inventory.update({
      where: { id: item.id },
      data: {
        quantity: remainingQty,
        lastUpdatedBy: req.user.name
      }
    });

    // 2. Record Sale Transaction
    const transaction = await prisma.saleTransaction.create({
      data: {
        adminId,
        inventoryId: item.id,
        itemName: item.itemName,
        quantity: qty,
        costPrice,
        sellingPrice,
        totalRevenue,
        totalProfit,
        customerName: customerName || 'Walk-in Customer',
        notes: notes || null
      }
    });

    // 3. Log Audit Trail
    await prisma.auditTrail.create({
      data: {
        adminId,
        action: 'SOLD',
        details: `Dispatched ${qty} units of "${item.itemName}" for $${totalRevenue} (Profit: $${totalProfit}). Stock remaining: ${remainingQty} units. Customer: ${customerName || 'Walk-in'}.`,
        userId: req.user.id,
        inventoryId: item.id
      }
    });

    // 4. Low Stock Alert Notification Check
    if (remainingQty <= item.minStockLevel) {
      await prisma.notification.create({
        data: {
          userId: adminId,
          title: '⚠️ Low Stock Alert',
          message: `Stock for "${item.itemName}" (SKU: ${item.sku}) has reached critical level (${remainingQty} units left). Min threshold is ${item.minStockLevel}.`,
          type: 'WARNING'
        }
      });
    }

    res.status(201).json({
      success: true,
      message: `Sale completed: ${qty} units sold for $${totalRevenue}. Net profit: $${totalProfit}.`,
      transaction,
      remainingStock: remainingQty
    });
  } catch (error) {
    console.error('Error recording sale:', error);
    res.status(500).json({ error: 'Failed to record sale transaction' });
  }
};

module.exports = {
  getFinancialAnalytics,
  recordSale
};
