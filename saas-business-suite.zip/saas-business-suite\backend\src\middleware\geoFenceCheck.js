/**
 * IP and Geo-fencing verification middleware for Employee Attendance Terminal.
 * Prevents remote / out-of-office fake check-ins.
 */
const verifyOfficeNetwork = (req, res, next) => {
  // If geofencing is bypassed via request setting (for testing/demo flexibility) or disabled:
  const enforceGeofence = process.env.ENFORCE_GEOFENCE === 'true' || req.headers['x-enforce-geofence'] === 'true';

  if (!enforceGeofence) {
    return next();
  }

  const clientIP = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '';
  const trustedOfficeIPs = (process.env.OFFICE_TRUSTED_IPS || '127.0.0.1,::1,::ffff:127.0.0.1,192.168.1.50').split(',');

  const isLocalOrTrusted = trustedOfficeIPs.some(ip => clientIP.includes(ip.trim()));

  // Optional Geolocation coordinate check if client sent latitude/longitude
  const { latitude, longitude } = req.body;
  if (latitude && longitude && process.env.OFFICE_LAT && process.env.OFFICE_LNG) {
    const officeLat = parseFloat(process.env.OFFICE_LAT);
    const officeLng = parseFloat(process.env.OFFICE_LNG);
    const maxRadiusMeters = parseFloat(process.env.OFFICE_RADIUS_METERS || '200');

    // Haversine distance formula
    const R = 6371e3; // metres
    const phi1 = (latitude * Math.PI) / 180;
    const phi2 = (officeLat * Math.PI) / 180;
    const deltaPhi = ((officeLat - latitude) * Math.PI) / 180;
    const deltaLambda = ((officeLng - longitude) * Math.PI) / 180;

    const a = Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
              Math.cos(phi1) * Math.cos(phi2) *
              Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c;

    if (distance > maxRadiusMeters) {
      return res.status(403).json({
        error: 'Location Restriction',
        message: `Check-in denied: You are ${Math.round(distance)}m away from office headquarters. Maximum allowed range is ${maxRadiusMeters}m.`
      });
    }
  } else if (!isLocalOrTrusted && process.env.NODE_ENV === 'production') {
    return res.status(403).json({
      error: 'Network Restriction',
      message: 'Check-in denied: You must be connected to the authorized Office Wi-Fi / Corporate Network to mark attendance.'
    });
  }

  next();
};

module.exports = { verifyOfficeNetwork };
