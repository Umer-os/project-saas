import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import CheckInButton from '../components/CheckInButton';
import api from '../services/api';
import {
  Clock,
  Calendar,
  FileText,
  User,
  Building2,
  CheckCircle2,
  AlertCircle,
  Briefcase,
  Send,
  History,
  ShieldCheck
} from 'lucide-react';

export default function EmployeeDashboard() {
  const [profile, setProfile] = useState(null);
  const [todayRecord, setTodayRecord] = useState(null);
  const [history, setHistory] = useState([]);
  const [leaves, setLeaves] = useState([]);
  const [loading, setLoading] = useState(true);

  // Leave Form
  const [showLeaveForm, setShowLeaveForm] = useState(false);
  const [leaveReason, setLeaveReason] = useState('');
  const [leaveStartDate, setLeaveStartDate] = useState('');
  const [leaveEndDate, setLeaveEndDate] = useState('');
  const [leaveSubmitting, setLeaveSubmitting] = useState(false);
  const [leaveNotice, setLeaveNotice] = useState(null);

  const fetchEmployeeData = async () => {
    try {
      const [profRes, todayRes, histRes, leavesRes] = await Promise.all([
        api.get('/employee/profile'),
        api.get('/attendance/my-today'),
        api.get('/attendance/my-history'),
        api.get('/employee/leaves')
      ]);

      if (profRes.data.success) setProfile(profRes.data.employee);
      if (todayRes.data.success) setTodayRecord(todayRes.data.record);
      if (histRes.data.success) setHistory(histRes.data.history);
      if (leavesRes.data.success) setLeaves(leavesRes.data.leaves);
    } catch (err) {
      console.error('Error fetching employee data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployeeData();
  }, []);

  const handleLeaveSubmit = async (e) => {
    e.preventDefault();
    setLeaveSubmitting(true);
    setLeaveNotice(null);

    try {
      const res = await api.post('/employee/leave', {
        reason: leaveReason,
        startDate: leaveStartDate,
        endDate: leaveEndDate
      });

      setLeaveNotice({ type: 'success', text: res.data.message });
      setLeaveReason('');
      setLeaveStartDate('');
      setLeaveEndDate('');
      setShowLeaveForm(false);
      fetchEmployeeData();
    } catch (err) {
      setLeaveNotice({ type: 'error', text: err.response?.data?.error || 'Failed to submit leave request' });
    } finally {
      setLeaveSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans">
      <Navbar />

      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Employee Banner */}
        <div className="bg-slate-800/90 rounded-2xl border border-slate-700/80 p-6 sm:p-8 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center text-xl font-bold">
              {profile?.name ? profile.name.charAt(0) : 'E'}
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 uppercase tracking-wider mb-1">
                Staff Self-Service Portal
              </div>
              <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                Welcome back, {profile?.name || 'Staff Member'}
              </h1>
              <p className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                <Building2 className="w-3.5 h-3.5 text-slate-500" />
                <span>{profile?.employerName || 'Corporate Workspace'}</span>
                <span>&bull;</span>
                <Briefcase className="w-3.5 h-3.5 text-slate-500" />
                <span>{profile?.department || 'Operations'}</span>
              </p>
            </div>
          </div>

          <div className="text-left sm:text-right bg-slate-900/60 p-3.5 rounded-xl border border-slate-700 text-xs">
            <div className="text-slate-400">Regular Work Schedule</div>
            <div className="font-bold text-slate-200 mt-0.5">
              {profile?.shiftStart || '09:00'} AM - {profile?.shiftEnd || '17:00'} PM
            </div>
            <div className="text-[10px] text-emerald-400 mt-0.5">10-min grace period allowed</div>
          </div>
        </div>

        {/* 1. PRIMARY ATTENDANCE CHECK-IN/OUT TERMINAL */}
        <CheckInButton
          onAttendanceUpdated={fetchEmployeeData}
          todayRecord={todayRecord}
          shiftInfo={profile}
        />

        {/* Leave Notice Banner */}
        {leaveNotice && (
          <div className={`p-4 rounded-xl flex items-center gap-2 text-sm ${
            leaveNotice.type === 'success'
              ? 'bg-emerald-950/70 border border-emerald-500/40 text-emerald-200'
              : 'bg-rose-950/70 border border-rose-500/40 text-rose-200'
          }`}>
            {leaveNotice.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <AlertCircle className="w-4 h-4 text-rose-400" />}
            {leaveNotice.text}
          </div>
        )}

        {/* 2. ATTENDANCE HISTORY TABLE */}
        <div className="bg-slate-800/80 rounded-2xl border border-slate-700/80 shadow-xl overflow-hidden p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <History className="w-5 h-5 text-emerald-400" />
              <h2 className="text-base font-bold text-white">My Attendance Log History</h2>
            </div>
            <span className="text-xs text-slate-400">{history.length} records</span>
          </div>

          <div className="overflow-x-auto rounded-xl border border-slate-700">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-900/90 uppercase tracking-wider text-[11px] text-slate-400 border-b border-slate-700">
                <tr>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Check-In</th>
                  <th className="py-3 px-4">Check-Out</th>
                  <th className="py-3 px-4">Total Hours</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/60">
                {history.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="py-6 text-center text-slate-500">
                      No attendance logs recorded yet. Punch check-in above to start.
                    </td>
                  </tr>
                ) : (
                  history.map((h) => (
                    <tr key={h.id} className="hover:bg-slate-700/30 transition">
                      <td className="py-3 px-4 font-semibold text-slate-200">
                        {new Date(h.date).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}
                      </td>
                      <td className="py-3 px-4 font-mono font-medium text-slate-200">
                        {h.checkIn ? new Date(h.checkIn).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-'}
                      </td>
                      <td className="py-3 px-4 font-mono font-medium text-slate-200">
                        {h.checkOut ? new Date(h.checkOut).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '-'}
                      </td>
                      <td className="py-3 px-4 font-bold text-emerald-400">
                        {h.totalHours ? `${h.totalHours} hrs` : '-'}
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          h.status === 'Present'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : h.status === 'Late'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                            : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                        }`}>
                          {h.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-400 text-[11px]">
                        {h.overriddenBy ? `Manual override by ${h.overriddenBy}` : (h.notes || 'Normal punch')}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* 3. LEAVE REQUESTS SELF-SERVICE */}
        <div className="bg-slate-800/80 rounded-2xl border border-slate-700/80 shadow-xl overflow-hidden p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-400" />
              <div>
                <h2 className="text-base font-bold text-white">Leave Submissions & Status</h2>
                <p className="text-xs text-slate-400">Submit time-off requests directly to your supervisor.</p>
              </div>
            </div>

            <button
              onClick={() => setShowLeaveForm(!showLeaveForm)}
              className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
            >
              <Send className="w-3.5 h-3.5" />
              {showLeaveForm ? 'Close Form' : 'Apply for Leave'}
            </button>
          </div>

          {/* Form */}
          {showLeaveForm && (
            <form onSubmit={handleLeaveSubmit} className="bg-slate-900/80 p-4 rounded-xl border border-slate-700 space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                  Reason for Time-Off / Absence
                </label>
                <textarea
                  required
                  rows="2"
                  value={leaveReason}
                  onChange={(e) => setLeaveReason(e.target.value)}
                  placeholder="e.g. Medical appointment, family event..."
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-500"
                ></textarea>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    Start Date
                  </label>
                  <input
                    type="date"
                    required
                    value={leaveStartDate}
                    onChange={(e) => setLeaveStartDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                    End Date
                  </label>
                  <input
                    type="date"
                    required
                    value={leaveEndDate}
                    onChange={(e) => setLeaveEndDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={leaveSubmitting}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white"
                >
                  {leaveSubmitting ? 'Submitting...' : 'Submit Request'}
                </button>
              </div>
            </form>
          )}

          {/* Leaves List */}
          <div className="overflow-x-auto rounded-xl border border-slate-700">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-900/90 uppercase tracking-wider text-[11px] text-slate-400 border-b border-slate-700">
                <tr>
                  <th className="py-3 px-4">Reason</th>
                  <th className="py-3 px-4">Period</th>
                  <th className="py-3 px-4">Applied Date</th>
                  <th className="py-3 px-4">Review Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/60">
                {leaves.length === 0 ? (
                  <tr>
                    <td colSpan="4" className="py-6 text-center text-slate-500">
                      No leave requests submitted yet.
                    </td>
                  </tr>
                ) : (
                  leaves.map((lr) => (
                    <tr key={lr.id} className="hover:bg-slate-700/30 transition">
                      <td className="py-3 px-4 font-medium text-slate-200">{lr.reason}</td>
                      <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                        {new Date(lr.startDate).toLocaleDateString()} - {new Date(lr.endDate).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4 text-slate-400">{new Date(lr.createdAt).toLocaleDateString()}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                          lr.status === 'Approved'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : lr.status === 'Rejected'
                            ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        }`}>
                          {lr.status}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}
