const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const prisma = require('../config/prisma');
const { JWT_SECRET } = require('../middleware/auth');

/**
 * Register a new user with strict Role-based restrictions.
 * Developer registration is strictly capped at a maximum of 2 accounts.
 */
const registerUser = async (req, res) => {
  const { name, email, password, role, businessName, adminId, shiftStart, shiftEnd, department, phone } = req.body;

  try {
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Validation Error', message: 'Name, email, and password are required.' });
    }

    const normalizedEmail = email.toLowerCase().trim();

    // Check if email already registered
    const existingUser = await prisma.user.findUnique({
      where: { email: normalizedEmail }
    });

    if (existingUser) {
      return res.status(400).json({ error: 'User Conflict', message: 'A user with this email address already exists.' });
    }

    const assignedRole = (role || 'EMPLOYEE').toUpperCase();

    // 🔒 RESTRICTION 1: Sirf max 2 Developers allow honge across the entire SaaS platform
    if (assignedRole === 'DEVELOPER') {
      const developerCount = await prisma.user.count({
        where: { role: 'DEVELOPER' }
      });

      if (developerCount >= 2) {
        return res.status(403).json({
          error: 'Registration Restricted',
          code: 'DEV_LIMIT_REACHED',
          message: 'Security Constraint: Maximum limit of 2 Platform Developers reached. Additional developer accounts cannot be created.'
        });
      }
    }

    // 🔒 RESTRICTION 2: If an Admin was previously blocked and attempts to re-register with same business name or email
    // or if an admin registering is rejected if company is banned
    const hashedPassword = await bcrypt.hash(password, 10);

    // Default subscription: 30 days trial/active period for Admins
    let subscriptionEndDate = null;
    if (assignedRole === 'ADMIN') {
      const futureDate = new Date();
      futureDate.setDate(futureDate.getDate() + 30);
      subscriptionEndDate = futureDate;
    }

    const newUser = await prisma.user.create({
      data: {
        name: name.trim(),
        email: normalizedEmail,
        password: hashedPassword,
        role: assignedRole,
        businessName: assignedRole === 'ADMIN' ? (businessName || `${name.trim()}'s Business`) : null,
        adminId: assignedRole === 'EMPLOYEE' ? adminId : null,
        shiftStart: shiftStart || '09:00',
        shiftEnd: shiftEnd || '17:00',
        department: department || 'General',
        phone: phone || null,
        subscriptionPlan: assignedRole === 'ADMIN' ? 'PREMIUM_PRO' : null,
        subscriptionEndDate,
        isBlocked: false
      }
    });

    // Create session token
    const token = jwt.sign(
      { id: newUser.id, role: newUser.role, email: newUser.email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.status(201).json({
      success: true,
      message: `${assignedRole} account created successfully.`,
      token,
      user: {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        businessName: newUser.businessName,
        adminId: newUser.adminId,
        shiftStart: newUser.shiftStart,
        shiftEnd: newUser.shiftEnd,
        isBlocked: newUser.isBlocked,
        subscriptionEndDate: newUser.subscriptionEndDate
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    return res.status(500).json({ error: 'Server Error', message: 'Failed to complete registration.' });
  }
};

/**
 * Login handler with built-in Kill-Switch and automated subscription checking.
 */
const loginUser = async (req, res) => {
  const { email, password } = req.body;

  try {
    if (!email || !password) {
      return res.status(400).json({ error: 'Validation Error', message: 'Email and password are required.' });
    }

    const normalizedEmail = email.toLowerCase().trim();
    const user = await prisma.user.findUnique({
      where: { email: normalizedEmail }
    });

    if (!user) {
      return res.status(404).json({ error: 'Not Found', message: 'No account found with this email address.' });
    }

    // 🔒 KILL-SWITCH ENFORCEMENT: Check if the user is directly blocked
    if (user.isBlocked) {
      return res.status(403).json({
        error: 'Account Suspended',
        code: 'BLOCKED',
        message: 'Your account access has been restricted by the SaaS platform administrator. Please contact developer support to resolve billing or licensing.'
      });
    }

    // Check if ADMIN has an expired subscription
    if (user.role === 'ADMIN' && user.subscriptionEndDate) {
      if (new Date(user.subscriptionEndDate) < new Date()) {
        await prisma.user.update({
          where: { id: user.id },
          data: { isBlocked: true }
        });

        return res.status(403).json({
          error: 'Subscription Expired',
          code: 'EXPIRED',
          message: 'Your SaaS commercial license expired on ' + user.subscriptionEndDate.toISOString().split('T')[0] + '. Please contact your provider to renew.'
        });
      }
    }

    // Check if EMPLOYEE belongs to a suspended/blocked Admin organization
    if (user.role === 'EMPLOYEE' && user.adminId) {
      const parentAdmin = await prisma.user.findUnique({
        where: { id: user.adminId }
      });

      if (parentAdmin && (parentAdmin.isBlocked || (parentAdmin.subscriptionEndDate && new Date(parentAdmin.subscriptionEndDate) < new Date()))) {
        return res.status(403).json({
          error: 'Company Suspended',
          code: 'PARENT_ADMIN_BLOCKED',
          message: `The company account (${parentAdmin.businessName || 'Your Employer'}) has been suspended for unpaid dues. Access is temporarily locked.`
        });
      }
    }

    // Verify Password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ error: 'Invalid Credentials', message: 'Incorrect email or password.' });
    }

    // Generate JWT token
    const token = jwt.sign(
      { id: user.id, role: user.role, email: user.email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.json({
      success: true,
      message: 'Login successful.',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        businessName: user.businessName,
        adminId: user.adminId,
        shiftStart: user.shiftStart,
        shiftEnd: user.shiftEnd,
        isBlocked: user.isBlocked,
        subscriptionPlan: user.subscriptionPlan,
        subscriptionEndDate: user.subscriptionEndDate
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({ error: 'Server Error', message: 'Failed to process login.' });
  }
};

/**
 * Forgot Password - Generates a secure single-use recovery token.
 */
const forgotPassword = async (req, res) => {
  const { email } = req.body;

  try {
    if (!email) {
      return res.status(400).json({ error: 'Validation Error', message: 'Please provide an email address.' });
    }

    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase().trim() }
    });

    if (!user) {
      return res.status(404).json({ error: 'Not Found', message: 'No user registered with this email address.' });
    }

    // Generate cryptographic reset token
    const rawResetToken = crypto.randomBytes(32).toString('hex');
    const hashedResetToken = crypto.createHash('sha256').update(rawResetToken).digest('hex');
    const tokenExpiry = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes lifetime

    await prisma.user.update({
      where: { id: user.id },
      data: {
        resetToken: hashedResetToken,
        resetTokenExpiry: tokenExpiry
      }
    });

    return res.json({
      success: true,
      message: 'Password reset instructions and verification token generated.',
      resetToken: rawResetToken, // In demo / local mode, returned directly for instant recovery
      expiresIn: '15 minutes'
    });
  } catch (error) {
    console.error('Forgot password error:', error);
    return res.status(500).json({ error: 'Server Error', message: 'Failed to process password reset request.' });
  }
};

/**
 * Reset Password - Validates token and updates user password securely.
 */
const resetPassword = async (req, res) => {
  const { token, newPassword } = req.body;

  try {
    if (!token || !newPassword) {
      return res.status(400).json({ error: 'Validation Error', message: 'Token and new password are required.' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ error: 'Validation Error', message: 'Password must be at least 6 characters long.' });
    }

    const hashedToken = crypto.createHash('sha256').update(token.trim()).digest('hex');

    const user = await prisma.user.findFirst({
      where: {
        resetToken: hashedToken,
        resetTokenExpiry: { gt: new Date() }
      }
    });

    if (!user) {
      return res.status(400).json({
        error: 'Invalid or Expired Token',
        message: 'The reset token is invalid, expired, or has already been used.'
      });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);

    await prisma.user.update({
      where: { id: user.id },
      data: {
        password: hashedPassword,
        resetToken: null,
        resetTokenExpiry: null
      }
    });

    return res.json({
      success: true,
      message: 'Password successfully updated. You may now log in with your new password.'
    });
  } catch (error) {
    console.error('Reset password error:', error);
    return res.status(500).json({ error: 'Server Error', message: 'Failed to reset password.' });
  }
};

/**
 * Get current authenticated user profile
 */
const getProfile = async (req, res) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user.id },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        businessName: true,
        adminId: true,
        shiftStart: true,
        shiftEnd: true,
        department: true,
        phone: true,
        isBlocked: true,
        subscriptionPlan: true,
        subscriptionEndDate: true,
        createdAt: true
      }
    });

    res.json({ success: true, user });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch user profile' });
  }
};

module.exports = {
  registerUser,
  loginUser,
  forgotPassword,
  resetPassword,
  getProfile
};
