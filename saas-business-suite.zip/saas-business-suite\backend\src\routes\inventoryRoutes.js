const express = require('express');
const router = express.Router();
const {
  getInventory,
  createInventoryItem,
  updateInventoryItem,
  deleteInventoryItem,
  getItemAuditHistory
} = require('../controllers/inventoryController');
const { authenticate, requireRole } = require('../middleware/auth');
const { verifyLicenseStatus } = require('../middleware/licenseCheck');

// Require authentication, ADMIN role, and license check
router.use(authenticate, requireRole('ADMIN'), verifyLicenseStatus);

router.get('/', getInventory);
router.post('/', createInventoryItem);
router.put('/:id', updateInventoryItem);
router.delete('/:id', deleteInventoryItem);
router.get('/audit', getItemAuditHistory);
router.get('/audit/:id', getItemAuditHistory);

module.exports = router;
