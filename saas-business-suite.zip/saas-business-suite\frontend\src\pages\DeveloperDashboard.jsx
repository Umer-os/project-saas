import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import StatCard from '../components/StatCard';
import api from '../services/api';
import {
  ShieldAlert,
  Users,
  Building2,
  Package,
  Sparkles,
  Lock,
  Unlock,
  Calendar,
  Clock,
  RefreshCw,
  Search,
  CheckCircle2,
  AlertTriangle,
  History,
  FileSpreadsheet
} from 'lucide-react';

export default function DeveloperDashboard() {
  const [stats, setStats] = useState(null);
  const [clients, setClients] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('clients'); // 'clients' | 'audit'
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL'); // 'ALL' | 'ACTIVE' | 'BLOCKED'

  // Modal states for Kill-Switch & Subscription renewal
  const [selectedAdmin, setSelectedAdmin] = useState(null);
  const [showBlockModal, setShowBlockModal] = useState(false);
  const [blockReason, setBlockReason] = useState('');
  const [showExtendModal, setShowExtendModal] = useState(false);
  const [daysToAdd, setDaysToAdd] = useState('30');
  const [selectedPlan, setSelectedPlan] = useState('ENTERPRISE_PRO');
  const [actionLoading, setActionLoading] = useState(false);
  const [notification, setNotification] = useState(null);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [statsRes, clientsRes, logsRes] = await Promise.all([
        api.get('/developer/stats'),
        api.get('/developer/clients'),
        api.get('/developer/audit-logs')
      ]);

      if (statsRes.data.success) setStats(statsRes.data.stats);
      if (clientsRes.data.success) setClients(clientsRes.data.clients);
      if (logsRes.data.success) setAuditLogs(logsRes.data.logs);
    } catch (err) {
      console.error('Error fetching developer data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const handleToggleBlock = async () => {
    if (!selectedAdmin) return;
    setActionLoading(true);

    try {
      const willBlock = !selectedAdmin.isBlocked;
      const res = await api.post('/developer/toggle-block', {
        adminId: selectedAdmin.id,
        isBlocked: willBlock,
        reason: blockReason || (willBlock ? 'Unpaid subscription balance' : 'Payment confirmed')
      });

      setNotification({
        type: 'success',
        text: res.data.message
      });

      setShowBlockModal(false);
      setBlockReason('');
      setSelectedAdmin(null);
      fetchDashboardData();
    } catch (err) {
      setNotification({
        type: 'error',
        text: err.response?.data?.message || 'Failed to toggle kill-switch'
      });
    } finally {
      setActionLoading(false);
    }
  };

  const handleExtendSubscription = async () => {
    if (!selectedAdmin) return;
    setActionLoading(true);

    try {
      const res = await api.post('/developer/update-subscription', {
        adminId: selectedAdmin.id,
        daysToAdd: parseInt(daysToAdd),
        planName: selectedPlan
      });

      setNotification({
        type: 'success',
        text: res.data.message
      });

      setShowExtendModal(false);
      setSelectedAdmin(null);
      fetchDashboardData();
    } catch (err) {
      setNotification({
        type: 'error',
        text: err.response?.data?.message || 'Failed to update subscription'
      });
    } finally {
      setActionLoading(false);
    }
  };

  const handleTriggerCronSweep = async () => {
    try {
      const res = await api.post('/developer/trigger-cron-check');
      setNotification({
        type: 'success',
        text: res.data.message
      });
      fetchDashboardData();
    } catch (err) {
      setNotification({
        type: 'error',
        text: 'Failed to run automated subscription check'
      });
    }
  };

  const filteredClients = clients.filter(c => {
    const matchesSearch = (c.businessName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
                          (c.name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
                          c.email.toLowerCase().includes(searchTerm.toLowerCase());

    if (statusFilter === 'ACTIVE') return matchesSearch && !c.isBlocked;
    if (statusFilter === 'BLOCKED') return matchesSearch && c.isBlocked;
    return matchesSearch;
  });

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans">
      <Navbar />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Developer Header Banner */}
        <div className="bg-gradient-to-r from-purple-900/60 via-slate-800 to-slate-900 rounded-2xl p-6 sm:p-8 border border-purple-800/40 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-purple-500/20 text-purple-300 border border-purple-500/30">
              <Sparkles className="w-3.5 h-3.5" /> SaaS Platform Master Command
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Developer & Platform Architect Portal
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl">
              Full authority to monitor tenant organizations, execute the commercial SaaS Kill-Switch for non-paying clients, manage recurring subscriptions, and inspect system audit logs.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleTriggerCronSweep}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition shadow-lg shadow-purple-600/20"
            >
              <RefreshCw className="w-4 h-4" /> Trigger Subscription Expiry Sweep
            </button>
          </div>
        </div>

        {/* Feedback Notification */}
        {notification && (
          <div className={`p-4 rounded-xl flex items-center justify-between text-sm ${
            notification.type === 'success'
              ? 'bg-emerald-950/70 border border-emerald-500/40 text-emerald-200'
              : 'bg-rose-950/70 border border-rose-500/40 text-rose-200'
          }`}>
            <div className="flex items-center gap-2 font-medium">
              {notification.type === 'success' ? <CheckCircle2 className="w-5 h-5 text-emerald-400" /> : <AlertTriangle className="w-5 h-5 text-rose-400" />}
              {notification.text}
            </div>
            <button onClick={() => setNotification(null)} className="text-xs opacity-75 hover:opacity-100">Dismiss</button>
          </div>
        )}

        {/* Platform Analytics Cards */}
        {stats && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              title="Total Business Clients"
              value={stats.totalAdmins}
              subtext={`${stats.activeAdmins} active tenants running`}
              icon={Building2}
              color="blue"
            />
            <StatCard
              title="Kill-Switch Suspended"
              value={stats.blockedAdmins}
              subtext="Restricted non-paying clients"
              icon={ShieldAlert}
              color="rose"
              alert={stats.blockedAdmins > 0}
            />
            <StatCard
              title="Platform Employees"
              value={stats.totalEmployees}
              subtext="Across all client businesses"
              icon={Users}
              color="emerald"
            />
            <StatCard
              title="Developer Security Rule"
              value={`${stats.totalDevelopers} / 2`}
              subtext={`${stats.developerSlotsRemaining} developer slots remaining`}
              icon={Sparkles}
              color="purple"
            />
          </div>
        )}

        {/* Tabs: Clients vs System Audit Logs */}
        <div className="bg-slate-800/80 rounded-2xl border border-slate-700/80 shadow-xl overflow-hidden">
          <div className="flex border-b border-slate-700/80 px-6 pt-4 gap-4">
            <button
              onClick={() => setActiveTab('clients')}
              className={`pb-4 text-sm font-bold flex items-center gap-2 transition border-b-2 ${
                activeTab === 'clients'
                  ? 'border-purple-400 text-purple-300'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Building2 className="w-4 h-4" /> Client Organizations ({clients.length})
            </button>
            <button
              onClick={() => setActiveTab('audit')}
              className={`pb-4 text-sm font-bold flex items-center gap-2 transition border-b-2 ${
                activeTab === 'audit'
                  ? 'border-purple-400 text-purple-300'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <History className="w-4 h-4" /> System Audit Logs ({auditLogs.length})
            </button>
          </div>

          {/* TAB 1: CLIENTS TABLE */}
          {activeTab === 'clients' && (
            <div className="p-6 space-y-4">
              {/* Search & Status Filters */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="relative w-full sm:w-80">
                  <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search by company, name, or email..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div className="flex items-center gap-2 self-start sm:self-auto text-xs">
                  <span className="text-slate-400">Filter:</span>
                  {['ALL', 'ACTIVE', 'BLOCKED'].map((st) => (
                    <button
                      key={st}
                      onClick={() => setStatusFilter(st)}
                      className={`px-3 py-1.5 rounded-lg font-medium transition ${
                        statusFilter === st
                          ? 'bg-purple-600 text-white'
                          : 'bg-slate-900 text-slate-400 hover:text-white'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>

              {/* Table */}
              <div className="overflow-x-auto rounded-xl border border-slate-700">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-900/90 uppercase tracking-wider text-[11px] text-slate-400 border-b border-slate-700">
                    <tr>
                      <th className="py-3 px-4">Business / Client Admin</th>
                      <th className="py-3 px-4">Plan & Expiry</th>
                      <th className="py-3 px-4">Employees</th>
                      <th className="py-3 px-4">Inventory</th>
                      <th className="py-3 px-4">SaaS Status</th>
                      <th className="py-3 px-4 text-right">Kill-Switch & Subscription</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/60">
                    {filteredClients.map((client) => {
                      const isExpired = client.subscriptionEndDate && new Date(client.subscriptionEndDate) < new Date();
                      return (
                        <tr key={client.id} className="hover:bg-slate-700/30 transition">
                          <td className="py-3.5 px-4">
                            <div className="font-bold text-white text-sm">
                              {client.businessName || 'Business Client'}
                            </div>
                            <div className="text-slate-400">{client.name} &bull; {client.email}</div>
                          </td>
                          <td className="py-3.5 px-4">
                            <div className="font-semibold text-slate-200">{client.subscriptionPlan || 'STANDARD'}</div>
                            <div className={`text-[11px] ${isExpired ? 'text-rose-400 font-bold' : 'text-slate-400'}`}>
                              {client.subscriptionEndDate ? new Date(client.subscriptionEndDate).toLocaleDateString() : 'Lifetime'}
                              {isExpired && ' (EXPIRED)'}
                            </div>
                          </td>
                          <td className="py-3.5 px-4 font-medium text-slate-200">
                            {client.employeeCount} staff
                          </td>
                          <td className="py-3.5 px-4 font-medium text-slate-200">
                            {client.inventoryCount} items
                          </td>
                          <td className="py-3.5 px-4">
                            {client.isBlocked ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40">
                                <Lock className="w-3 h-3 text-rose-400" /> BLOCKED
                              </span>
                            ) : isExpired ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                                <Clock className="w-3 h-3 text-amber-400" /> EXPIRED
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                                <CheckCircle2 className="w-3 h-3 text-emerald-400" /> ACTIVE
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 text-right space-x-2">
                            {/* Toggle Block Button */}
                            <button
                              onClick={() => {
                                setSelectedAdmin(client);
                                setShowBlockModal(true);
                              }}
                              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition inline-flex items-center gap-1.5 ${
                                client.isBlocked
                                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                                  : 'bg-rose-600/80 hover:bg-rose-600 text-white'
                              }`}
                            >
                              {client.isBlocked ? (
                                <>
                                  <Unlock className="w-3.5 h-3.5" /> Unblock Access
                                </>
                              ) : (
                                <>
                                  <Lock className="w-3.5 h-3.5" /> Block Client
                                </>
                              )}
                            </button>

                            {/* Extend Subscription */}
                            <button
                              onClick={() => {
                                setSelectedAdmin(client);
                                setShowExtendModal(true);
                              }}
                              className="px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-700 hover:bg-slate-600 text-slate-200 transition inline-flex items-center gap-1.5"
                            >
                              <Calendar className="w-3.5 h-3.5" /> Manage License
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 2: SYSTEM AUDIT LOGS */}
          {activeTab === 'audit' && (
            <div className="p-6">
              <div className="overflow-x-auto rounded-xl border border-slate-700">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-900/90 uppercase tracking-wider text-[11px] text-slate-400 border-b border-slate-700">
                    <tr>
                      <th className="py-3 px-4">Timestamp</th>
                      <th className="py-3 px-4">Action</th>
                      <th className="py-3 px-4">Executed By</th>
                      <th className="py-3 px-4">Audit Details</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-700/60">
                    {auditLogs.map((log) => (
                      <tr key={log.id} className="hover:bg-slate-700/30 transition">
                        <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                          {new Date(log.createdAt).toLocaleString()}
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            log.action.includes('BLOCK')
                              ? 'bg-rose-900/60 text-rose-300 border border-rose-700'
                              : log.action.includes('UNBLOCK')
                              ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-700'
                              : 'bg-purple-900/60 text-purple-300 border border-purple-700'
                          }`}>
                            {log.action}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-semibold text-slate-200">
                          {log.developer?.name || 'SaaS Platform Engine'}
                        </td>
                        <td className="py-3 px-4 text-slate-300 leading-relaxed">
                          {log.details}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* MODAL 1: KILL-SWITCH TOGGLE */}
        {showBlockModal && selectedAdmin && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-slate-800 border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl">
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  selectedAdmin.isBlocked ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                }`}>
                  {selectedAdmin.isBlocked ? <Unlock className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">
                    {selectedAdmin.isBlocked ? 'Unblock Client Account' : 'Activate SaaS Kill-Switch'}
                  </h3>
                  <p className="text-xs text-slate-400">{selectedAdmin.businessName || selectedAdmin.name}</p>
                </div>
              </div>

              <p className="text-xs text-slate-300 mb-4 leading-relaxed">
                {selectedAdmin.isBlocked
                  ? 'Restoring access will instantly allow this client and all their linked staff to sign in, use attendance terminals, and manage inventory.'
                  : 'Blocking this client will immediately revoke their access. Their dashboard and all staff terminals will display the Subscription Blocked screen. They will not be able to log in or create new accounts.'}
              </p>

              <div className="mb-4">
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Audit Reason / Note:
                </label>
                <input
                  type="text"
                  value={blockReason}
                  onChange={(e) => setBlockReason(e.target.value)}
                  placeholder={selectedAdmin.isBlocked ? 'e.g. Invoice #2034 Cleared' : 'e.g. Non-payment of March SaaS bill'}
                  className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowBlockModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={actionLoading}
                  onClick={handleToggleBlock}
                  className={`px-4 py-2 rounded-xl text-xs font-bold text-white shadow-lg transition ${
                    selectedAdmin.isBlocked
                      ? 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/20'
                      : 'bg-rose-600 hover:bg-rose-500 shadow-rose-600/20'
                  }`}
                >
                  {actionLoading ? 'Processing...' : selectedAdmin.isBlocked ? 'Confirm Unblock' : 'Confirm Kill-Switch Lock'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* MODAL 2: EXTEND SUBSCRIPTION */}
        {showExtendModal && selectedAdmin && (
          <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-slate-800 border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Renew / Extend Subscription</h3>
                  <p className="text-xs text-slate-400">{selectedAdmin.businessName || selectedAdmin.name}</p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Select Plan Tier:
                  </label>
                  <select
                    value={selectedPlan}
                    onChange={(e) => setSelectedPlan(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white"
                  >
                    <option value="STARTER_PRO">Starter Business ($49/mo)</option>
                    <option value="ENTERPRISE_PRO">Enterprise Corporate Suite ($199/mo)</option>
                    <option value="UNLIMITED_TIER">Unlimited Multi-Branch ($499/mo)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                    Extension Period:
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {['30', '90', '365'].map((days) => (
                      <button
                        key={days}
                        type="button"
                        onClick={() => setDaysToAdd(days)}
                        className={`p-2 rounded-xl text-xs font-bold border transition ${
                          daysToAdd === days
                            ? 'bg-purple-600/30 border-purple-500 text-purple-200'
                            : 'bg-slate-900 border-slate-700 text-slate-400'
                        }`}
                      >
                        +{days} Days
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-6">
                <button
                  type="button"
                  onClick={() => setShowExtendModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={actionLoading}
                  onClick={handleExtendSubscription}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-purple-600 hover:bg-purple-500 text-white shadow-lg shadow-purple-600/20"
                >
                  {actionLoading ? 'Updating...' : 'Save & Renew Access'}
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
