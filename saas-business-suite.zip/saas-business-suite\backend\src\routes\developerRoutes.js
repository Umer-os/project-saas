const express = require('express');
const router = express.Router();
const {
  getPlatformStats,
  getAllClients,
  toggleAdminBlockStatus,
  updateClientSubscription,
  getSystemAuditLogs,
  triggerManualSubscriptionCheck
} = require('../controllers/developerController');
const { authenticate, requireRole } = require('../middleware/auth');

// All developer routes require authentication and DEVELOPER role
router.use(authenticate, requireRole('DEVELOPER'));

router.get('/stats', getPlatformStats);
router.get('/clients', getAllClients);
router.post('/toggle-block', toggleAdminBlockStatus);
router.post('/update-subscription', updateClientSubscription);
router.get('/audit-logs', getSystemAuditLogs);
router.post('/trigger-cron-check', triggerManualSubscriptionCheck);

module.exports = router;
