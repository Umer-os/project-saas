const express = require('express');
const router = express.Router();
const {
  checkIn,
  checkOut,
  getAdminAttendance,
  overrideAttendance,
  deleteAttendance,
  getMyTodayAttendance,
  getMyAttendanceHistory
} = require('../controllers/attendanceController');
const { authenticate, requireRole } = require('../middleware/auth');
const { verifyLicenseStatus } = require('../middleware/licenseCheck');
const { verifyOfficeNetwork } = require('../middleware/geoFenceCheck');

// Base authentication & license verification
router.use(authenticate, verifyLicenseStatus);

// Employee terminal endpoints
router.post('/check-in', verifyOfficeNetwork, checkIn);
router.post('/check-out', checkOut);
router.get('/my-today', getMyTodayAttendance);
router.get('/my-history', getMyAttendanceHistory);

// Admin-only attendance management endpoints
router.get('/admin', requireRole('ADMIN'), getAdminAttendance);
router.put('/admin/override/:id', requireRole('ADMIN'), overrideAttendance);
router.delete('/admin/:id', requireRole('ADMIN'), deleteAttendance);

module.exports = router;
