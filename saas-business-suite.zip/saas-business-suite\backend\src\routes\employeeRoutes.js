const express = require('express');
const router = express.Router();
const {
  submitLeaveRequest,
  getMyLeaves,
  getMyDetails
} = require('../controllers/employeeController');
const { authenticate, requireRole } = require('../middleware/auth');
const { verifyLicenseStatus } = require('../middleware/licenseCheck');

// Require authentication, EMPLOYEE role, and license check
router.use(authenticate, requireRole('EMPLOYEE'), verifyLicenseStatus);

router.get('/profile', getMyDetails);
router.post('/leave', submitLeaveRequest);
router.get('/leaves', getMyLeaves);

module.exports = router;
