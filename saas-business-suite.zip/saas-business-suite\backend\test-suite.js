const BASE_URL = 'http://localhost:5000/api';

async function req(url, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  const res = await fetch(`${BASE_URL}${url}`, {
    ...options,
    headers,
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, ok: res.ok, data };
}

async function runTests() {
  console.log('🧪 Starting Full SaaS Commercial Test Suite (v2.5 Enterprise Edition)...\n');
  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  ✔ PASS: ${message}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${message}`);
      failed++;
    }
  }

  try {
    // 1. Health Check
    console.log('--- Test 1: API Health Check ---');
    const health = await req('/health');
    assert(health.data.status === 'online', 'Server is online and responding at /api/health');

    // 2. Developer Limit Check (Max 2 Rule)
    console.log('\n--- Test 2: Developer Registration Limits (Max 2 rule) ---');
    const dev3 = await req('/auth/register', {
      method: 'POST',
      body: {
        name: 'Third Developer (Forbidden)',
        email: 'dev3_test2@saas.com',
        password: 'Developer123!',
        role: 'DEVELOPER'
      }
    });
    assert(
      dev3.status === 403 && dev3.data.code === 'DEV_LIMIT_REACHED',
      `Correctly rejected 3rd Developer with code DEV_LIMIT_REACHED: "${dev3.data.message}"`
    );

    // 3. SaaS Kill-Switch Test (Blocked Admin Attempting Login)
    console.log('\n--- Test 3: SaaS Kill-Switch on Suspended/Non-Paying Admin ---');
    const blockedLogin = await req('/auth/login', {
      method: 'POST',
      body: {
        email: 'blocked@retail.com',
        password: 'Admin123!'
      }
    });
    assert(
      blockedLogin.status === 403,
      `Correctly blocked login for suspended client with 403 Forbidden: "${blockedLogin.data.message}"`
    );

    // 4. Active Admin Login & Dashboard Stats
    console.log('\n--- Test 4: Active Admin Login & Dashboard Stats ---');
    const adminLogin = await req('/auth/login', {
      method: 'POST',
      body: {
        email: 'admin@corporate.com',
        password: 'Admin123!'
      }
    });
    assert(adminLogin.data.success && adminLogin.data.user.role === 'ADMIN', 'Active Admin logged in successfully');
    const adminToken = adminLogin.data.token;

    const adminStats = await req('/admin/stats', {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    assert(
      adminStats.data.success && adminStats.data.stats.totalEmployees >= 3,
      `Admin retrieved stats: ${adminStats.data.stats.totalEmployees} employees, ${adminStats.data.stats.presentToday} present today.`
    );

    // 5. Inventory Dynamic Search, CRUD & Audit Trail
    console.log('\n--- Test 5: Inventory CRUD with Automatic Audit Trail Logging ---');
    const newSku = `SKU-POS-${Date.now()}`;
    const createInv = await req('/inventory', {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: {
        itemName: 'Enterprise Handheld PDA Scanner',
        sku: newSku,
        category: 'Hardware',
        quantity: 20,
        minStockLevel: 5,
        costPrice: 150,
        sellingPrice: 280
      }
    });
    assert(createInv.data.success, 'Created new inventory stock item');
    const createdItemId = createInv.data.item.id;

    // 6. Sales Dispatch & Profit/Loss Auto-Computation
    console.log('\n--- Test 6: Sales Dispatch & Profit/Loss Financial Analytics ---');
    const saleRes = await req('/admin/sales', {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: {
        inventoryId: createdItemId,
        quantity: 5,
        customSellingPrice: 300, // Revenue = 5 * 300 = $1500; Cost = 5 * 150 = $750; Profit = $750
        customerName: 'Metro Logistics Distribution'
      }
    });
    assert(
      saleRes.data.success && saleRes.data.remainingStock === 15,
      `Recorded sale: Deducted 5 units (15 left). Revenue: $1500, Profit: $750.`
    );

    const financialsRes = await req('/admin/financials', {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    assert(
      financialsRes.data.success && financialsRes.data.summary.grossProfit > 0,
      `Financials computed: Total Revenue: $${financialsRes.data.summary.totalRevenue}, Net Profit: $${financialsRes.data.summary.grossProfit} (${financialsRes.data.summary.profitMargin}% margin).`
    );

    // 7. Payroll & Performance Computation
    console.log('\n--- Test 7: Staff Attendance Hours & Payroll Computation ---');
    const payrollRes = await req('/admin/payroll', {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    assert(
      payrollRes.data.success && payrollRes.data.payroll.length >= 3,
      `Calculated payroll for ${payrollRes.data.payroll.length} staff. Total disbursement: $${payrollRes.data.summary.totalPayrollDisbursement}.`
    );

    // 8. In-App Notification Center
    console.log('\n--- Test 8: Real-Time In-App Notification Center ---');
    const notifRes = await req('/notifications', {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    assert(notifRes.data.success, `Retrieved ${notifRes.data.count} notifications for admin (${notifRes.data.unreadCount} unread).`);

    const readAllRes = await req('/notifications/read-all', {
      method: 'PUT',
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    assert(readAllRes.data.success, 'Successfully marked all notifications as read.');

    // 9. Developer Platform Authority & Kill-Switch Toggle
    console.log('\n--- Test 9: Developer Platform Authority & Kill-Switch ---');
    const devLogin = await req('/auth/login', {
      method: 'POST',
      body: {
        email: 'developer@saas.com',
        password: 'Developer123!'
      }
    });
    assert(devLogin.data.success && devLogin.data.user.role === 'DEVELOPER', 'Developer logged in successfully');
    const devToken = devLogin.data.token;

    const clientsRes = await req('/developer/clients', {
      headers: { Authorization: `Bearer ${devToken}` }
    });
    const blockedClient = clientsRes.data.clients.find(c => c.email === 'blocked@retail.com');

    // Developer renews/extends subscription by 30 days and clears block
    const renewRes = await req('/developer/update-subscription', {
      method: 'POST',
      headers: { Authorization: `Bearer ${devToken}` },
      body: {
        adminId: blockedClient.id,
        daysToAdd: 30,
        planName: 'ENTERPRISE_PRO'
      }
    });
    assert(renewRes.data.success, 'Developer extended subscription and unblocked client');

    // Re-block for demonstration showcase
    await req('/developer/toggle-block', {
      method: 'POST',
      headers: { Authorization: `Bearer ${devToken}` },
      body: {
        adminId: blockedClient.id,
        isBlocked: true,
        reason: 'Re-blocked for demonstration showcase'
      }
    });

    // 10. Automated Subscription Expiry Sweep
    console.log('\n--- Test 10: Automated Subscription Expiry Cron Sweep ---');
    const sweepRes = await req('/developer/trigger-cron-check', {
      method: 'POST',
      headers: { Authorization: `Bearer ${devToken}` }
    });
    assert(sweepRes.data.success, `Subscription cron sweep triggered successfully: ${sweepRes.data.message}`);

    console.log('\n=======================================================');
    console.log(`🏆 ALL ENTERPRISE TESTS COMPLETE: ${passed} PASSED, ${failed} FAILED`);
    console.log('=======================================================');

  } catch (error) {
    console.error('Test suite error:', error);
  }
}

runTests();
