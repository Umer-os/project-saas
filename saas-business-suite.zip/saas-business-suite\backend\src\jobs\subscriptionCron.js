const cron = require('node-cron');
const prisma = require('../config/prisma');

/**
 * Checks all active ADMIN accounts and flags expired subscriptions as blocked.
 * Records system audit log for automated suspensions.
 */
const checkSubscriptionExpiryNow = async () => {
  try {
    const now = new Date();

    const expiredAdmins = await prisma.user.findMany({
      where: {
        role: 'ADMIN',
        isBlocked: false,
        subscriptionEndDate: {
          not: null,
          lt: now
        }
      }
    });

    if (expiredAdmins.length === 0) {
      console.log('[CRON SUBSCRIPTION] Scan complete: No expired admin licenses found.');
      return { count: 0, expiredAdmins: [] };
    }

    console.log(`[CRON SUBSCRIPTION] Found ${expiredAdmins.length} expired admin accounts. Applying SaaS Kill-Switch...`);

    // Block them and create system audit log entries
    for (const admin of expiredAdmins) {
      await prisma.user.update({
        where: { id: admin.id },
        data: { isBlocked: true }
      });

      // Find any developer to associate system action with, or record system-level log
      const developer = await prisma.user.findFirst({
        where: { role: 'DEVELOPER' }
      });

      if (developer) {
        await prisma.systemAuditLog.create({
          data: {
            developerId: developer.id,
            targetAdminId: admin.id,
            action: 'AUTO_SUSPEND_EXPIRED_SUBSCRIPTION',
            details: `Automated Cron Suspension: Subscription for client "${admin.businessName || admin.name}" (${admin.email}) expired on ${admin.subscriptionEndDate.toISOString().split('T')[0]}.`
          }
        });
      }
    }

    console.log(`[CRON SUBSCRIPTION] Successfully suspended ${expiredAdmins.length} expired admin accounts.`);
    return { count: expiredAdmins.length, expiredAdmins };
  } catch (error) {
    console.error('[CRON ERROR] Failed to process subscription expiry check:', error);
    throw error;
  }
};

/**
 * Schedules daily midnight sweep ('0 0 * * *').
 * Also runs on initial start.
 */
const initSubscriptionCron = () => {
  // Run once on server startup
  checkSubscriptionExpiryNow().catch(err => console.error('Initial subscription check error:', err));

  // Run everyday at midnight (00:00)
  cron.schedule('0 0 * * *', () => {
    console.log('[CRON SUBSCRIPTION] Triggering scheduled midnight subscription expiry verification...');
    checkSubscriptionExpiryNow();
  });
};

module.exports = { initSubscriptionCron, checkSubscriptionExpiryNow };
