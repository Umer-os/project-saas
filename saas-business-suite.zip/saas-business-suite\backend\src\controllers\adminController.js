const bcrypt = require('bcryptjs');
const prisma = require('../config/prisma');

/**
 * Get Admin Dashboard Overview Metrics
 */
const getAdminDashboardStats = async (req, res) => {
  const adminId = req.user.id;

  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // Total employees under this admin
    const totalEmployees = await prisma.user.count({
      where: { role: 'EMPLOYEE', adminId }
    });

    // Attendance today
    const attendancesToday = await prisma.attendance.findMany({
      where: {
        adminId,
        date: {
          gte: today,
          lt: tomorrow
        }
      },
      include: {
        user: {
          select: { name: true, shiftStart: true }
        }
      }
    });

    const presentToday = attendancesToday.filter(a => a.status === 'Present' || a.status === 'Late').length;
    const lateComers = attendancesToday.filter(a => a.status === 'Late').length;

    // Inventory items
    const inventoryItems = await prisma.inventory.findMany({
      where: { adminId }
    });

    const lowStockItems = inventoryItems.filter(item => item.quantity <= item.minStockLevel);
    const totalInventoryValue = inventoryItems.reduce((acc, curr) => acc + (curr.quantity * (curr.costPrice || 0)), 0);

    // Pending Leaves
    const pendingLeaves = await prisma.leaveRequest.count({
      where: { adminId, status: 'Pending' }
    });

    res.json({
      success: true,
      stats: {
        totalEmployees,
        presentToday,
        lateComers,
        absentToday: Math.max(0, totalEmployees - presentToday),
        totalStockItems: inventoryItems.length,
        lowStockCount: lowStockItems.length,
        lowStockItems: lowStockItems.slice(0, 5),
        totalInventoryValue,
        pendingLeaves
      }
    });
  } catch (error) {
    console.error('Error fetching admin dashboard stats:', error);
    res.status(500).json({ error: 'Failed to fetch dashboard metrics' });
  }
};

/**
 * List all employees for the logged-in Admin
 */
const getEmployees = async (req, res) => {
  const adminId = req.user.id;

  try {
    const employees = await prisma.user.findMany({
      where: { role: 'EMPLOYEE', adminId },
      select: {
        id: true,
        name: true,
        email: true,
        department: true,
        phone: true,
        shiftStart: true,
        shiftEnd: true,
        salary: true,
        isBlocked: true,
        createdAt: true
      },
      orderBy: { createdAt: 'desc' }
    });

    res.json({ success: true, employees });
  } catch (error) {
    console.error('Error fetching employees:', error);
    res.status(500).json({ error: 'Failed to fetch employees' });
  }
};

/**
 * Add a new Employee under this Admin
 */
const createEmployee = async (req, res) => {
  const adminId = req.user.id;
  const { name, email, password, department, phone, shiftStart, shiftEnd, salary } = req.body;

  try {
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email, and password are required' });
    }

    const existing = await prisma.user.findUnique({
      where: { email: email.toLowerCase().trim() }
    });

    if (existing) {
      return res.status(400).json({ error: 'An account with this email already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const employee = await prisma.user.create({
      data: {
        name: name.trim(),
        email: email.toLowerCase().trim(),
        password: hashedPassword,
        role: 'EMPLOYEE',
        adminId,
        department: department || 'Operations',
        phone: phone || null,
        shiftStart: shiftStart || '09:00',
        shiftEnd: shiftEnd || '17:00',
        salary: salary ? parseFloat(salary) : 0
      }
    });

    res.status(201).json({
      success: true,
      message: 'Employee successfully created',
      employee: {
        id: employee.id,
        name: employee.name,
        email: employee.email,
        department: employee.department,
        shiftStart: employee.shiftStart,
        shiftEnd: employee.shiftEnd
      }
    });
  } catch (error) {
    console.error('Error creating employee:', error);
    res.status(500).json({ error: 'Failed to create employee' });
  }
};

/**
 * Update employee details / shift timings
 */
const updateEmployee = async (req, res) => {
  const adminId = req.user.id;
  const { id } = req.params;
  const { name, department, phone, shiftStart, shiftEnd, salary, isBlocked } = req.body;

  try {
    const employee = await prisma.user.findFirst({
      where: { id, adminId, role: 'EMPLOYEE' }
    });

    if (!employee) {
      return res.status(404).json({ error: 'Employee not found under your organization' });
    }

    const updated = await prisma.user.update({
      where: { id },
      data: {
        name: name !== undefined ? name.trim() : undefined,
        department: department !== undefined ? department : undefined,
        phone: phone !== undefined ? phone : undefined,
        shiftStart: shiftStart !== undefined ? shiftStart : undefined,
        shiftEnd: shiftEnd !== undefined ? shiftEnd : undefined,
        salary: salary !== undefined ? parseFloat(salary) : undefined,
        isBlocked: isBlocked !== undefined ? isBlocked : undefined
      }
    });

    res.json({ success: true, message: 'Employee updated successfully', employee: updated });
  } catch (error) {
    console.error('Error updating employee:', error);
    res.status(500).json({ error: 'Failed to update employee' });
  }
};

/**
 * Delete an employee
 */
const deleteEmployee = async (req, res) => {
  const adminId = req.user.id;
  const { id } = req.params;

  try {
    const employee = await prisma.user.findFirst({
      where: { id, adminId, role: 'EMPLOYEE' }
    });

    if (!employee) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    await prisma.user.delete({ where: { id } });

    res.json({ success: true, message: 'Employee profile deleted successfully' });
  } catch (error) {
    console.error('Error deleting employee:', error);
    res.status(500).json({ error: 'Failed to delete employee' });
  }
};

/**
 * Get all leave requests for this Admin
 */
const getLeaveRequests = async (req, res) => {
  const adminId = req.user.id;

  try {
    const leaveRequests = await prisma.leaveRequest.findMany({
      where: { adminId },
      include: {
        user: {
          select: { name: true, email: true, department: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    res.json({ success: true, leaveRequests });
  } catch (error) {
    console.error('Error fetching leave requests:', error);
    res.status(500).json({ error: 'Failed to fetch leave requests' });
  }
};

/**
 * Review (Approve / Reject) Leave Request
 */
const updateLeaveStatus = async (req, res) => {
  const adminId = req.user.id;
  const { id } = req.params;
  const { status } = req.body; // 'Approved' | 'Rejected'

  try {
    if (!['Approved', 'Rejected'].includes(status)) {
      return res.status(400).json({ error: 'Status must be Approved or Rejected' });
    }

    const leave = await prisma.leaveRequest.findFirst({
      where: { id, adminId }
    });

    if (!leave) {
      return res.status(404).json({ error: 'Leave request not found' });
    }

    const updated = await prisma.leaveRequest.update({
      where: { id },
      data: {
        status,
        reviewedBy: req.user.name
      }
    });

    res.json({ success: true, message: `Leave request ${status.toLowerCase()}`, leave: updated });
  } catch (error) {
    console.error('Error updating leave status:', error);
    res.status(500).json({ error: 'Failed to update leave status' });
  }
};

module.exports = {
  getAdminDashboardStats,
  getEmployees,
  createEmployee,
  updateEmployee,
  deleteEmployee,
  getLeaveRequests,
  updateLeaveStatus
};
